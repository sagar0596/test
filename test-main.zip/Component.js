sap.ui.define([
	"sap/ui/core/library",
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"./model/models",
	"sap/ui/core/routing/History",
	"sap/ui/Device",
	"sap/ui/model/resource/ResourceModel",
	 "com/forex/app/reuse/js/index"
], function(library, UIComponent,JSONModel, models, History, Device) {
	

	return UIComponent.extend("com.forex.app.Component", {


		metadata: {
			manifest: "json",
			interfaces: [library.IAsyncContentCreation]
		},

		init: function () {

			window.metatoken="eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI5MGU3OWUyYjJjOWFhNjQwOTdmODgxOTc4MTc2ZGFmOCIsInBlcm1pc3Npb25zIjpbXSwiYWNjZXNzUnVsZXMiOlt7ImlkIjoidHJhZGluZy1hY2NvdW50LW1hbmFnZW1lbnQtYXBpIiwibWV0aG9kcyI6WyJ0cmFkaW5nLWFjY291bnQtbWFuYWdlbWVudC1hcGk6cmVzdDpwdWJsaWM6KjoqIl0sInJvbGVzIjpbInJlYWRlciIsIndyaXRlciJdLCJyZXNvdXJjZXMiOlsiKjokVVNFUl9JRCQ6KiJdfSx7ImlkIjoibWV0YWFwaS1yZXN0LWFwaSIsIm1ldGhvZHMiOlsibWV0YWFwaS1hcGk6cmVzdDpwdWJsaWM6KjoqIl0sInJvbGVzIjpbInJlYWRlciIsIndyaXRlciJdLCJyZXNvdXJjZXMiOlsiKjokVVNFUl9JRCQ6KiJdfSx7ImlkIjoibWV0YWFwaS1ycGMtYXBpIiwibWV0aG9kcyI6WyJtZXRhYXBpLWFwaTp3czpwdWJsaWM6KjoqIl0sInJvbGVzIjpbInJlYWRlciIsIndyaXRlciJdLCJyZXNvdXJjZXMiOlsiKjokVVNFUl9JRCQ6KiJdfSx7ImlkIjoibWV0YWFwaS1yZWFsLXRpbWUtc3RyZWFtaW5nLWFwaSIsIm1ldGhvZHMiOlsibWV0YWFwaS1hcGk6d3M6cHVibGljOio6KiJdLCJyb2xlcyI6WyJyZWFkZXIiLCJ3cml0ZXIiXSwicmVzb3VyY2VzIjpbIio6JFVTRVJfSUQkOioiXX0seyJpZCI6Im1ldGFzdGF0cy1hcGkiLCJtZXRob2RzIjpbIm1ldGFzdGF0cy1hcGk6cmVzdDpwdWJsaWM6KjoqIl0sInJvbGVzIjpbInJlYWRlciIsIndyaXRlciJdLCJyZXNvdXJjZXMiOlsiKjokVVNFUl9JRCQ6KiJdfSx7ImlkIjoicmlzay1tYW5hZ2VtZW50LWFwaSIsIm1ldGhvZHMiOlsicmlzay1tYW5hZ2VtZW50LWFwaTpyZXN0OnB1YmxpYzoqOioiXSwicm9sZXMiOlsicmVhZGVyIiwid3JpdGVyIl0sInJlc291cmNlcyI6WyIqOiRVU0VSX0lEJDoqIl19LHsiaWQiOiJjb3B5ZmFjdG9yeS1hcGkiLCJtZXRob2RzIjpbImNvcHlmYWN0b3J5LWFwaTpyZXN0OnB1YmxpYzoqOioiXSwicm9sZXMiOlsicmVhZGVyIiwid3JpdGVyIl0sInJlc291cmNlcyI6WyIqOiRVU0VSX0lEJDoqIl19LHsiaWQiOiJtdC1tYW5hZ2VyLWFwaSIsIm1ldGhvZHMiOlsibXQtbWFuYWdlci1hcGk6cmVzdDpkZWFsaW5nOio6KiIsIm10LW1hbmFnZXItYXBpOnJlc3Q6cHVibGljOio6KiJdLCJyb2xlcyI6WyJyZWFkZXIiLCJ3cml0ZXIiXSwicmVzb3VyY2VzIjpbIio6JFVTRVJfSUQkOioiXX0seyJpZCI6ImJpbGxpbmctYXBpIiwibWV0aG9kcyI6WyJiaWxsaW5nLWFwaTpyZXN0OnB1YmxpYzoqOioiXSwicm9sZXMiOlsicmVhZGVyIl0sInJlc291cmNlcyI6WyIqOiRVU0VSX0lEJDoqIl19XSwiaWdub3JlUmF0ZUxpbWl0cyI6ZmFsc2UsInRva2VuSWQiOiIyMDIxMDIxMyIsImltcGVyc29uYXRlZCI6ZmFsc2UsInJlYWxVc2VySWQiOiI5MGU3OWUyYjJjOWFhNjQwOTdmODgxOTc4MTc2ZGFmOCIsImlhdCI6MTc0MDI3Mzk0OSwiZXhwIjoxNzQ4MDQ5OTQ5fQ.CnOLoHVNGT_0VcqNVgQi_Yg7tBKf3R92QeLZih4zJ3MPiUAHFw7QRVhr8rSSAbnWpwp9_3xiJR3XMDr716AE-1BqupsZ_pwyzFFcNklqWEbf4705gKxyCKaoiokCdhYFpKevcPM665IE_BJRDHjeqlptH_9uisgnCVWhWvMCiwuM7BE6qfpHaSAfQgL37z9BNmo5YqEYjg8_tIZFqpF4Af5XwX7jqlH0i9B230XFe6W3NbTNgxAfYClxkkTDYZKlecV0ZRpYqTGHBuKKedLzsjWVe4uVPS7JMQfbXfa2PKuVHJrXviEvBoxDCO4nW_FNwL2g4tapMQxMQenEBN95-C7bEBJFJdPczgWmaTN7GMPCicftMhLtKvMIBqVPRYita1gQkpp9xzDibfF4aaOnPwhVpcEKXpDfXmtAlKySz99aIY14zPV8qHPBHM2-MqfLRtOgAmDhsHHpoc-gMjfY_pQ0H_lcw0eAdzmtVmmG8AUGwYjskeKPAjCphU01JQ6IqqDOoFQU4OfuEFfW8mk2ayKK9-xv6hjrXuOm6thowvPP5hqXc5T1Byfah6NA3jx-vNU6jDM1vqZYqphPxXTFk2cRC7_xRftPXBu8tAM6wfjEOpi3p2ER_s70bzaYwsyQ71-KUWcGshvMMW7rHP_YVgt8vUXHTRk9viUrFuHHPqI";
			window.api = new MetaApi.default(metatoken);
			window.accountid="2e17dece-c9ea-4146-a13c-151bf5d71ad7";
			
		//	window.metaStats = new MetaApi.MetaStats(metatoken);
			window.terminalurl="https://mt-client-api-v1.london.agiliumtrade.ai";
			window.copyfactoryurl="https://copyfactory-api-v1.london.agiliumtrade.ai";

			axios.defaults.baseURL = "https://mt-provisioning-api-v1.agiliumtrade.agiliumtrade.ai";
			axios.defaults.headers.common['auth-token'] = `${metatoken}`;

		
			
			let oAppModel = new JSONModel({
				accounts: []
				
			  });
		
			 
			  sap.ui.getCore().setModel(oAppModel,"mts_accounts")
this.setModel(oAppModel,"mts_accounts");


let oWatchList = new JSONModel({
	accounts: []
	
  });

 
  sap.ui.getCore().setModel(oWatchList,"watchlist")
this.setModel(oWatchList,"watchlist");


let oHistory = new JSONModel({
	history: []
	
  });

 
  sap.ui.getCore().setModel(oHistory,"history")
this.setModel(oHistory,"history");


let oPositions = new JSONModel({
	positions: []
	
  });

 
  sap.ui.getCore().setModel(oPositions,"positions")
this.setModel(oPositions,"positions");


			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// create the views based on the url/hash
			this.getRouter().initialize();
		},

		myNavBack: function () {
			var oHistory = History.getInstance();
			var oPrevHash = oHistory.getPreviousHash();
			if (oPrevHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("masterSettings", {}, true);
			}
		},

		getContentDensityClass: function () {
			if (!this._sContentDensityClass) {
				if (!Device.support.touch){
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		}
	});
});