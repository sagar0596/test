sap.ui.define([
    './BaseController',
	"sap/base/Log",
	"sap/ui/table/library",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat",
	"sap/ui/thirdparty/jquery",
	"sap/ui/core/date/UI5Date",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/ui/core/library'
], function(BaseController,Log, library, Controller, MessageToast, JSONModel, DateFormat, jQuery, UI5Date,Filter,FilterOperator,coreLibrary) {
	"use strict";

	const SelectionBehavior = library.SelectionBehavior;
	const SelectionMode = library.SelectionMode;
	return BaseController.extend("com.forex.app.controller.WatchList", {
		onInit: function() {
			// set explored app's demo model on this sample
			const oJSONModel = this.initSampleDataModel();
		
		},
        onAfterRendering:function(){
          

        },

		initSampleDataModel: function() {
			let buyOrderTypes=[{
				"id":"ORDER_TYPE_BUY",
				"name":"MARKET"
			},{
				"id":"ORDER_TYPE_BUY_LIMIT",
				"name":"LIMIT"
			}];

			sap.ui.getCore().getModel("watchlist").setProperty("/buyOrderTypes",buyOrderTypes);

			let sellOrderTypes=[{
				"id":"ORDER_TYPE_SELL",
				"name":"MARKET"
			},{
				"id":"ORDER_TYPE_SELL_LIMIT",
				"name":"LIMIT"
			}];

			sap.ui.getCore().getModel("watchlist").setProperty("/sellOrderTypes",sellOrderTypes);
			sap.ui.getCore().getModel("watchlist").setProperty("/add",{});
			sap.ui.getCore().getModel("watchlist").setProperty("/add/targetTypePoints",true);
			sap.ui.getCore().getModel("watchlist").setProperty("/add/stopLossTypePoints",true);
			sap.ui.getCore().getModel("watchlist").setProperty("/add/lossvalue","0.00");
			sap.ui.getCore().getModel("watchlist").setProperty("/add/profitvalue","0.00");
			sap.ui.getCore().getModel("watchlist").setProperty("/add/lotsize","0.01");


			
			
			this.getAllStrategies();
			this.loadSymbols();
		},

		handleBuyorderTypes :function(oEvent){

			let ValueState = coreLibrary.ValueState
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Please enter a buy order type");
			} else {
			 sap.ui.getCore().getModel("watchlist").setProperty("/add/buy_order_type",sSelectedKey);
				oValidatedComboBox.setValueState(ValueState.None);
			}

		},
		handleSellOrderTypes:function(oEvent){

			
			let ValueState = coreLibrary.ValueState
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Please enter a sell order type");
			} else {
			 sap.ui.getCore().getModel("history").setProperty("/add/sell_order_type",sSelectedKey);
				oValidatedComboBox.setValueState(ValueState.None);
			}

		},
		onAddSymbol:async function(){
			let data =sap.ui.getCore().getModel("watchlist").getProperty("/add");


			let url =`${window.terminalurl}/users/current/accounts/${accountid}/trade`
			let postdata={};
			postdata.actionType=data.buy_order_type;
			postdata.symbol=data.symbol;
			postdata.volume=parseFloat(data.lotsize);

			let strategyData=await this.getStrategy(data.strategyid);
			let updateSymbolsData={};
			updateSymbolsData.name=strategyData.name;
			updateSymbolsData.accountId=strategyData.accountId;
			updateSymbolsData.description=strategyData.description;
			

			if(!strategyData.symbolsTraded ){
				updateSymbolsData.symbolsTraded=[data.symbol]
			}else{
				let index =strategyData.symbolsTraded.indexOf(data.symbol);
				if(index==-1){
					updateSymbolsData.symbolsTraded.push(data.symbol);
				}
			}

			await axios.put(`${window.copyfactoryurl}/users/current/configuration/strategies/${data.strategyid}`,updateSymbolsData);

			
			if(data.targetTypePoints){
				if(data.buy_order_type=="ORDER_TYPE_BUY"){
					let symbolMarketValue =await this.getCurrentSymbolMarketValue(data.symbol);
				//	postdata.symbol="BTC";
			
					postdata.takeProfit= parseFloat(symbolMarketValue)+parseFloat(data.profitvalue);
					postdata.stopLoss= parseFloat(symbolMarketValue)-parseFloat(data.lossvalue);
0
				}


			}

		        await axios.post(url,postdata);
		},
		handleSquareOFFALL: async function(){
			await this.getOpenOrders();
			let data=sap.ui.getCore().getModel("watchlist").getProperty("/openorders") ;
			let url =`${window.terminalurl}/users/current/accounts/${accountid}/trade`;
			for(let i=0;i<data.length;i++){
				let payload={
					"actionType":"ORDER_CANCEL",
					"orderId":data[i].id
				}
				 axios.post(url,payload);
			}

		},
		handleCancelOrder:async function(oEvent){

			let spath =oEvent.getSource().getBindingContext("watchlist").getPath();
			let order=sap.ui.getCore().getModel("watchlist").getProperty(spath);

			let payload={
				"actionType":"ORDER_CANCEL",
				"orderId":order.id
			}
			 axios.post(url,payload);

		},

		getOpenOrders: async function(){
			let url =`${window.terminalurl}/users/current/accounts/${accountid}/orders`;
			let response =await axios.get(url);
			let data=response.data;
			for(let i=0;i<data.length;i++){

			}
sap.ui.getCore().getModel("watchlist").setProperty("/openorders",data);
		

		},

		getStrategy:async function(strategyid){
		let strategiesurl=`${window.copyfactoryurl}/users/current/configuration/strategies/${strategyid}`;
		let response =await axios.get(strategiesurl);
		return response.data;
		},

		getCurrentSymbolMarketValue:async function(symbolid){

			let url =`${window.terminalurl}/users/current/accounts/${accountid}/symbols/${symbolid}/current-price`
			

			const response = await axios.get(url);
			return response.data.ask


		},
		
		handleStrategyChange :function(oEvent){

			let ValueState = coreLibrary.ValueState
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Please select Strategy ");
			} else {
			 sap.ui.getCore().getModel("watchlist").setProperty("/add/strategyid",sSelectedKey);
				oValidatedComboBox.setValueState(ValueState.None);
			}

		},
		setTargetTypePoints:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/add/targetTypePoints",value);
			
		},
		setTargetTypePecentage:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/add/targetTypePoints",!value);
		},


		setStopLostTypePoints:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/add/stopLossTypePoints",value);
			
		},
		setStopLostTypePercentage:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/add/stopLossTypePoints",!value);
		},

		getAllStrategies:async function(){

			let strategiesurl=`${window.copyfactoryurl}/users/current/configuration/strategies`
			let strategies = await this.fetchAllData([strategiesurl]);
		
			let strategiesArray=[]
			
			sap.ui.getCore().getModel("watchlist").setProperty("/strategies",strategies[0]);

		},

		onSelectionModeChange: function(oEvent) {
			if (oEvent.getParameter("selectedItem").getKey() === "All") {
				MessageToast.show("selectionMode:All is deprecated. Please select another one.");
				return;
			}
			const oTable = this.byId("table1");
			oTable.setSelectionMode(oEvent.getParameter("selectedItem").getKey());
		},

		onBehaviourModeChange: function(oEvent) {
			const oTable = this.byId("table1");
			oTable.setSelectionBehavior(oEvent.getParameter("selectedItem").getKey());
		},

		onSwitchChange: function(oEvent) {
			const oTable = this.byId("table1");
			oTable.setEnableSelectAll(oEvent.getParameter("state"));
		},

		

		handleSymbolValueHelp : function (oEvent) {
			var oView = this.getView();
			this.inputId = oEvent.getSource().getId();

			// create value help dialog
			if (!this._pSymbolValueHelpDialog) {
				this._pSymbolValueHelpDialog = this.loadFragment({
				
					name:  "com.forex.app.fragment.Dialog",
					controller: this
				}).then(function(oValueHelpDialog){
					oView.addDependent(oValueHelpDialog);
					return oValueHelpDialog;
				});
			}

			this._pSymbolValueHelpDialog.then(function(oValueHelpDialog){
				debugger;
				// open value help dialog
				oValueHelpDialog.open();
			}).catch(function(err){
				debugger;
			});
		},

		loadSymbols:async function(){
			let symbolsurl=`${window.terminalurl}/users/current/accounts/${window.accountid}/symbols`
			let symbols = await this.fetchAllData([symbolsurl]);
			debugger;
			let symbolArray=[]
			for(let i=0;i<symbols[0].length;i++){
				symbolArray.push({
					"name":symbols[0][i]
				})

			}
			sap.ui.getCore().getModel("watchlist").setProperty("/symbols",symbolArray);
			

		},
		_handleSymbolValueHelpSearch : function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"name",
				FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleSymbolValueHelpClose : function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput =sap.ui.getCore().byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		

		openManagedStategies: async function(evt) {
            var oView = this.getView();
		//	await this.loadSymbols();
			if (!this.oMPDialog) {
				this.oMPDialog = this.loadFragment({
					name: "com.forex.app.fragment.WatchList",
                    controller: this
				});
			}
			this.oMPDialog.then(function (oDialog) {
                oView.addDependent(oDialog); 
				this.oDialog = oDialog;
				this.oDialog.open();
               
				
			}.bind(this));
		},

		getContextByIndex: function(evt) {
			const oTable = this.byId("table1");
			const iIndex = oTable.getSelectedIndex();
			let sMsg;
			if (iIndex < 0) {
				sMsg = "no item selected";
			} else {
				sMsg = oTable.getContextByIndex(iIndex);
			}
			MessageToast.show(sMsg);
		},

		clearSelection: function(evt) {
			this.byId("table1").clearSelection();
		},

		formatAvailableToObjectState: function(bAvailable) {
			return bAvailable ? "Success" : "Error";
		},

		formatAvailableToIcon: function(bAvailable) {
			return bAvailable ? "sap-icon://accept" : "sap-icon://decline";
		},

		handleDetailsPress: function(oEvent) {
			MessageToast.show("Details for product with id " + this.getView().getModel().getProperty("ProductId", oEvent.getSource().getBindingContext()));
		}

	});

});