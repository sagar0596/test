sap.ui.define([
	'./BaseController',
	'sap/ui/model/json/JSONModel',
	'sap/ui/Device',
	'com/forex/app/model/formatter'
], function (BaseController, JSONModel, Device, formatter) {
	"use strict";
	return BaseController.extend("com.forex.app.controller.Home", {
		formatter: formatter,

		onInit: function () {
			this.initSampleDataModel();
			
			
		},
		initSampleDataModel:async function(){
			let url=`${window.terminalurl}/users/current/accounts/${window.accountid}/account-information`;
			let result =await axios.get(url);

			sap.ui.getCore().getModel("home").setProperty("/account",result.data);
			let activePositions =await this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/positions`);
			
			sap.ui.getCore().getModel("home").setProperty("/activepositionscount",activePositions.length);

			sap.ui.getCore().getModel("home").setProperty("/activepositionscount",activePositions.length);


			let subscribers=await axios.get(`${window.copyfactoryurl}/users/current/configuration/subscribers`);
			sap.ui.getCore().getModel("home").setProperty("/subscriberscount",subscribers.data.length);
	
		}
		
	});
});