

sap.ui.define([
    'sap/ui/core/library',
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (coreLibrary,BaseController, JSONModel) {
    "use strict";

    
    

    return BaseController.extend("com.forex.app.controller.History", {
        onInit: function () {
            sap.ui.getCore().getModel("history").setProperty("/search", {});

            // Load JSON data from file and set it as the model
            this.initSampleDataModel();
            this.getAllAccountsList();
			

            // Log the model data
           // console.log("Model Data:", oModel.getData());
        },

        

        getGroup: function (oContext) {
            return oContext.getProperty('name');
        },
        handleAccountChange:function(oEvent){
            let ValueState = coreLibrary.ValueState
                var oValidatedComboBox = oEvent.getSource(),
                    sSelectedKey = oValidatedComboBox.getSelectedKey(),
                    sValue = oValidatedComboBox.getValue();
    
                if (!sSelectedKey && sValue) {
                    oValidatedComboBox.setValueState(ValueState.Error);
                    oValidatedComboBox.setValueStateText("Please enter a valid Account!");
                } else {
                 sap.ui.getCore().getModel("history").setProperty("/search/accountid",sSelectedKey);
                    oValidatedComboBox.setValueState(ValueState.None);
                }
                this.peformSearch()
           
        },

        getAllAccountsList:async function(){

            let accounts=(await axios.get("/users/current/accounts")).data;

            accounts=[{
                "name":"All Accounts",
                "_id":"ALL_ACCOUNTS"
            }].concat(accounts)


            sap.ui.getCore().getModel("history").setProperty("/allaccounts",accounts);

        },
        onDateChange:function(oEvent){
            if(oEvent.getParameter("valid")){
                let value = oEvent.getParameter("value");
                if(value){
                    let aDateRangerValues =sap.m.DynamicDateRange.toDates(oEvent.getParameter("value"));
                    let fromDate=aDateRangerValues[0].toISOString();
                    let toDate=aDateRangerValues[1].toISOString();
                    sap.ui.getCore().getModel("history").setProperty("/search/fromDate", fromDate);
                    sap.ui.getCore().getModel("history").setProperty("/search/toDate", toDate);
    
                }else{
                    sap.ui.getCore().getModel("history").setProperty("/search/fromDate", null);
                    sap.ui.getCore().getModel("history").setProperty("/search/toDate", null);
    
                }
                this.peformSearch();


            }
        },

        peformSearch:async function(){
            let account_id =sap.ui.getCore().getModel("history").getProperty("/search/accountid");
            let fromDate= sap.ui.getCore().getModel("history").getProperty("/search/fromDate");
            let toDate=sap.ui.getCore().getModel("history").getProperty("/search/toDate");
            sap.ui.getCore().getModel("history").setProperty("/history",[]);
            let historyresult=[];
            if( account_id && fromDate && toDate){

                if(account_id=="ALL_ACCOUNTS"){

                    let accounts=await axios.get("/users/current/accounts");
    
                    for(let i=0;i<accounts.data.length;i++){
                        let account=accounts.data[i];
                        let account_id=account._id;
                        
                        let data=await this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${account_id}/history-orders/time/${fromDate}/${toDate}`);

                        for(let j=0;j<data.length;j++){

                            data[j].name=account["name"]
                            let date   = new Date( data[j]["time"]); 
                            data[j]["time"] = 
                       ("00" + (date.getMonth() + 1)).slice(-2) 
                       + "/" + ("00" + date.getDate()).slice(-2) 
                       + "/" + date.getFullYear() + " " 
                       + ("00" + date.getHours()).slice(-2) + ":" 
                       + ("00" + date.getMinutes()).slice(-2) 
                       + ":" + ("00" + date.getSeconds()).slice(-2);
    
                       historyresult.push(data[j]);


                        }
                    }
                   // let historydata= sap.ui.getCore().getModel("history").getProperty("/history");
                   
                    sap.ui.getCore().getModel("history").setProperty("/history",historyresult);
    
    
                }else{
                   let accounts= sap.ui.getCore().getModel("history").getProperty("/allaccounts")
                   let filteredAccount= accounts.filter(function (el) {
                        return el._id==account_id
                      });
                      let account=filteredAccount[0];
                   
                        let data=await this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${account_id}/history-orders/time/${fromDate}/${toDate}`);
                        for(let i=0;i<data.length;i++){
                            data[i].name=account["name"]
                            let date   = new Date( data[i]["time"]); 
                            data[i]["time"] = 
                       ("00" + (date.getMonth() + 1)).slice(-2) 
                       + "/" + ("00" + date.getDate()).slice(-2) 
                       + "/" + date.getFullYear() + " " 
                       + ("00" + date.getHours()).slice(-2) + ":" 
                       + ("00" + date.getMinutes()).slice(-2) 
                       + ":" + ("00" + date.getSeconds()).slice(-2);
        
                       historyresult.push(data[i]);
    

                        }
    
                   sap.ui.getCore().getModel("history").setProperty("/history",historyresult);
                }

            }


            
        },


   getGroupHeader: function (oGroup) {
          
            return new sap.m.GroupHeaderListItem({
                title: oGroup.key
            })
        },



        initSampleDataModel: async function() {

            let accounts=await axios.get("/users/current/accounts");
            let searchAccount=sap.ui.getCore().getModel("history").getProperty("/search/accountid")
			   let promise=[];
				for(let i=0;i<accounts.data.length;i++){
                    let account=accounts.data[i];
                    let accountid=account._id;
 
                    if(searchAccount && (searchAccount==account._id ||searchAccount=="ALL_ACCOUNTS" )){
                       
                        
                        promise.push(this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/positions`));
                    }

				}
			let result =await Promise.all(promise);
            let finalresult=[];
            for(let i=0;i<result.length;i++){
                 
                let account=accounts.data[i];
                account.closeButton=false;
                let accountPositions=[];
                for(let j=0;j<result[i].length;j++){
                 delete account["symbol"];
                 delete account["type"];
                 result[i][j]["accountid"]=account["_id"]; 
                  let date   = new Date( result[i][j]["time"]); 
                     result[i][j]["time"] = 
                ("00" + (date.getMonth() + 1)).slice(-2) 
                + "/" + ("00" + date.getDate()).slice(-2) 
                + "/" + date.getFullYear() + " " 
                + ("00" + date.getHours()).slice(-2) + ":" 
                + ("00" + date.getMinutes()).slice(-2) 
                + ":" + ("00" + date.getSeconds()).slice(-2);
                result[i][j]["closeButton"]=true; 
                accountPositions.push( result[i][j]);

                }
                account["accounts"]=accountPositions;
                finalresult.push(account);
            }

            sap.ui.getCore().getModel("positions").setProperty("/positions",{});
            sap.ui.getCore().getModel("positions").setProperty("/positions/accounts",finalresult);


		},


        initSampleDataModel: async function() {

            let accounts=await axios.get("/users/current/accounts?limit=10&offset=0");
				let accounturls=[];
				let accounttermialurl=[];
                let promise=[];
				for(let i=0;i<accounts.data.length;i++){
					let account=accounts.data[i];
					let accountid=account._id;
					
					promise.push(this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/history-orders/time/2025-02-01T04:00:00.000Z/2025-02-26T06:00:00.000Z`));
				}
			let result =await Promise.all(promise);
            let finalresult=[];
            for(let i=0;i<result.length;i++){
                let account=accounts.data[i]
                for(let j=0;j<result[i].length;j++){
                    result[i][j]["name"]=account["name"];
                  let date   = new Date( result[i][j]["time"]); 
                     result[i][j]["time"] = 
                ("00" + (date.getMonth() + 1)).slice(-2) 
                + "/" + ("00" + date.getDate()).slice(-2) 
                + "/" + date.getFullYear() + " " 
                + ("00" + date.getHours()).slice(-2) + ":" 
                + ("00" + date.getMinutes()).slice(-2) 
                + ":" + ("00" + date.getSeconds()).slice(-2); 
                    finalresult.push( result[i][j]);

                }
            }
            debugger;


            sap.ui.getCore().getModel("history").setProperty("/history",finalresult);

		},
    });
});