sap.ui.define([
	'./BaseController',
	'sap/ui/model/json/JSONModel',
	'sap/ui/Device',
	'com/forex/app/model/formatter',
	'sap/ui/core/date/UI5Date'
], function (BaseController, JSONModel, Device, formatter,UI5Date) {
	"use strict";
	return BaseController.extend("com.forex.app.controller.Home", {
		formatter: formatter,

		onInit: function () {
			this.initSampleDataModel();
			
			
		},
		initSampleDataModel:async function(){
			let url=`${window.terminalurl}/users/current/accounts/${window.accountid}/account-information`;
			let result =await axios.get(url);

			sap.ui.getCore().getModel("home").setProperty("/account",result.data);
			let activePositions =await this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/positions`);
			
			sap.ui.getCore().getModel("home").setProperty("/activepositionscount",activePositions.length);

			sap.ui.getCore().getModel("home").setProperty("/activepositions",activePositions);


			let subscribers=await axios.get(`${window.copyfactoryurl}/users/current/configuration/subscribers`);
			sap.ui.getCore().getModel("home").setProperty("/subscriberscount",subscribers.data.length);
			
			
			const today = new Date();
today.setDate(today.getDate());

// Set the start of today (00:00:00)
const startOfToday = new Date(today);
startOfToday.setHours(0, 0, 0, 0); // Midnight

// Set the end of today (23:59:59)
const endOfToday = new Date(today);
endOfToday.setHours(23, 59, 59, 999); 


			let aDateRangerValues =[startOfToday,endOfToday]
                      
			let fromDate=aDateRangerValues[0].toISOString();
			let toDate=aDateRangerValues[1].toISOString();

			let historydeals=await this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/history-deals/time/${fromDate}/${toDate}`);

			/*for(let i=0;i<historydeals.length;i++){
				let history = historydeals[i];
				
				let jsDate = new Date(history.time);
				let ui5Date = UI5Date.getInstance(jsDate);
				history.uidate=ui5Date;

			}*/


			sap.ui.getCore().getModel("home").setProperty("/history",historydeals);

		}
		
	});
});