

sap.ui.define([
    'sap/ui/core/library',
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (coreLibrary,BaseController, JSONModel) {
    "use strict";

    
    

    return BaseController.extend("com.forex.app.controller.History", {
        onInit: function () {
        
            // Load JSON data from file and set it as the model
            this.initSampleDataModel();
        
			

        },
        initSampleDataModel :async function(){
            let strategies=await axios.get(`${window.copyfactoryurl}/users/current/configuration/strategies`);

            for(let i=0;i<strategies.data.length;i++){
                let strategy =strategies.data[i];
                if(strategies.data[i].symbolFilter && strategies.data[i].symbolFilter.included){

                }

            }

            sap.ui.getCore().getModel("managestrategies").setProperty("/strategies",strategies.data)
	
        }


        

     
    

        


        
    });
});