

sap.ui.define([
    'sap/ui/core/library',
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (coreLibrary,BaseController, JSONModel) {
    "use strict";

    
    

    return BaseController.extend("com.forex.app.controller.History", {
        onInit: function () {
        
            // Load JSON data from file and set it as the model
            this.initSampleDataModel();
        
			

        },
        initSampleDataModel :async function(){
            let strategies=await axios.get(`${window.copyfactoryurl}/users/current/configuration/strategies`);

            for(let i=0;i<strategies.data.length;i++){
                let strategy =strategies.data[i];
                strategy.symbols=[];
                if(strategy.symbolFilter && strategy.symbolFilter.included){
                    for(let j=0;j<strategy.symbolFilter.included.length;j++){
                        strategy.symbols.push({
                            "symbol":strategy.symbolFilter.included[j]
                        })
                    }

                }

            }

            sap.ui.getCore().getModel("managestrategies").setProperty("/strategies",strategies.data)
	
        }


        

     
    

        


        
    });
});