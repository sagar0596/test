sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/m/MessageBox",
], function(Controller, UIComponent,MessageBox) {
	"use strict";

	return Controller.extend("com.forex.app.controller.BaseController", {

		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter : function () {
			return UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel : function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel : function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Returns a promises which resolves with the resource bundle value of the given key <code>sI18nKey</code>
		 *
		 * @public
		 * @param {string} sI18nKey The key
		 * @param {sap.ui.core.model.ResourceModel} oResourceModel The resource model
		 * @param {string[]} [aPlaceholderValues] The values which will repalce the placeholders in the i18n value
		 * @returns {Promise<string>} The promise
		 */
		getBundleTextByModel: function(sI18nKey, oResourceModel, aPlaceholderValues){
			return oResourceModel.getResourceBundle().then(function(oBundle){
				return oBundle.getText(sI18nKey, aPlaceholderValues);
			});
		},
		fetchDataWithErrorHandling : async function(url)  {
   
			const response = await axios.get(url);
			return response.data; // Return the data from the response
	   
	},

	deviationIndicator:function(profit){
		if(!profit){
			return;
		}

		if(parseFloat(profit)>0){
			return  sap.m.DeviationIndicator.Up
		}else if(parseFloat(profit)<0){
			return  sap.m.DeviationIndicator.Down

		}else{
			return  sap.m.DeviationIndicator.None
		}
	},

	positionFormater:function(positiontype){
		
		if(!positiontype){
			return;
		}

		if(positiontype=="POSITION_TYPE_BUY"){
			return "BUY"
		}else{
			return "SELL"
		}
	},

	positionFormater:function(positiontype){
		
		if(!positiontype){
			return;
		}

		if(positiontype=="POSITION_TYPE_BUY"){
			return "BUY"
		}else{
			return "SELL"
		}
	},
	
	limitOrderFormater:function(type){
		
		if(!type){
			return;
		}

		if(type=="ORDER_TYPE_BUY_LIMIT" || type =="ORDER_TYPE_BUY"){
			return "BUY"
		} else if( type=="ORDER_TYPE_SELL_LIMIT" || type =="ORDER_TYPE_SELL"){
			return "SELL"
		}
	},

	historyDealsFormater:function(type){
		
		if(!type){
			return;
		}

		if(type=="DEAL_TYPE_BUY"){
			return "BUY"
		}else if(type=="DEAL_TYPE_SELL"){
			return "SELL"
		}
	},
	historyDealsDirectionFormater:function(type){
		
		if(!type){
			return;
		}

		if(type=="DEAL_ENTRY_IN"){
			return "IN"
		}else if(type=="DEAL_ENTRY_OUT"){
			return "OUT"
		}
		else if(type=="DEAL_ENTRY_INOUT"){
			return "REVERSE"
		}
		else if(type=="DEAL_ENTRY_OUT_BY"){
			return "OPPOSITE"
		}
	},

	historyDealsDirectionStateFormater:function(type){
		
		if(!type){
			return;
		}

		if(type=="DEAL_ENTRY_IN"){
			return sap.ui.core.IndicationColor.Indication05;

		}else if(type=="DEAL_ENTRY_OUT"){
			return sap.ui.core.IndicationColor.Indication01;

		}
		else if(type=="DEAL_ENTRY_INOUT"){
			return sap.ui.core.IndicationColor.Indication03;
		}
		else if(type=="DEAL_ENTRY_OUT_BY"){
			return sap.ui.core.IndicationColor.Indication08;
		}
	},

	historyDealsStateFormater:function(type){
		
		if(!type){
			return;
		}

		if(type=="DEAL_TYPE_BUY"){
			return sap.ui.core.IndicationColor.Indication15;
		}else if(type=="DEAL_TYPE_SELL"){
			return sap.ui.core.IndicationColor.Indication12;
		}
	},

	positionStateFormater:function(positiontype){
		
		if(!positiontype){
			return;
		}

		if(positiontype=="POSITION_TYPE_BUY"){
			return sap.ui.core.IndicationColor.Indication15;

		}else{
			return sap.ui.core.IndicationColor.Indication12;
		}
	},
	accountStateFormater:function(state){
		
		if(!state){
			return;
		}

		if(state=="DEPLOYED"){
			return sap.ui.core.IndicationColor.Indication15;

		}else{
			return sap.ui.core.IndicationColor.Indication12;
		}
	},

	limitOrderStateFormater:function(type){
		
		if(!type){
			return;
		}

		if(type=="ORDER_TYPE_BUY_LIMIT" || type =="ORDER_TYPE_BUY"){
			return sap.ui.core.IndicationColor.Indication15;
		} else if( type=="ORDER_TYPE_SELL_LIMIT" || type =="ORDER_TYPE_SELL"){
			return sap.ui.core.IndicationColor.Indication12;
		}

		
	},

	objectNumberState:function(profit){

		if(!profit){
			return;
		}

		if(profit>0){
			return sap.ui.core.ValueState.Success;

		}else if(profit<0){
			return  sap.ui.core.ValueState.Error;

		}else{
			return  sap.ui.core.ValueState.Information;


		}

	},

	deviationColor:function(profit){
		if(!profit){
			return;
		}

		if(parseFloat(profit)>0){
			return  sap.m.ValueColor.Good;

		}else if(parseFloat(profit)<0){
			return  sap.m.ValueColor.Error;

		}else{
			return  sap.m.ValueColor.Neutral;

		}
	},
	
	// Main function to make parallel API calls
	 fetchAllData : async function(apiUrls) {
		
			// Create an array of promises with error handling
			const promises = apiUrls.map(url => this.fetchDataWithErrorHandling(url));
	
			// Use Promise.all to make parallel calls
			const results = await Promise.all(promises);
			return results;
	
		   
	   
	},


	handleTradingErrorHandling:async function(subsciberAccountid,payload,sucessFunction,errorFunction,context){

		try{
			let publisherAccount=accountid;
			if(subsciberAccountid){
				publisherAccount=subsciberAccountid;

			}

			 let url=`${window.terminalurl}/users/current/accounts/${publisherAccount}/trade`
			let  response =await axios.post(url,payload);
			
			

				let sucessCodes=["ERR_NO_ERROR", "TRADE_RETCODE_PLACED","TRADE_RETCODE_DONE", "TRADE_RETCODE_DONE_PARTIAL", "TRADE_RETCODE_NO_CHANGES"];
			
			
		
				
				if(sucessCodes.indexOf(response.data.stringCode)!=-1){
					MessageBox.information(response.data.message);
					if(sucessFunction){
						sucessFunction.apply(context);
					}

				}else{
					MessageBox.error(response.data.message);
				}

			}catch(err){
				let errorMessage=[]
				for(let i=0;i<err.response.data.details.length;i++){
					errorMessage ="\n"+JSON.stringify(err.response.data.details[i]);
				}
				MessageBox.error(err.response.data.message +"\n "+errorMessage);
				if(errorFunction){
					errorFunction.apply(context);
				}

			}

	},
	



	});

});