

sap.ui.define([
    'sap/ui/core/library',
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (coreLibrary,BaseController, JSONModel) {
    "use strict";

    
    

    return BaseController.extend("com.forex.app.controller.History", {
        onInit: function () {
        
            // Load JSON data from file and set it as the model
            this.initSampleDataModel();
        
			

        },
        initSampleDataModel :function(){
            let strategies=await axios.get(`${window.copyfactoryurl}/users/current/configuration/strategies`);
	return strategies.data;
        }


        

     
    

        


        
    });
});