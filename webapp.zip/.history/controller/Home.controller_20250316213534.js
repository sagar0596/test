sap.ui.define([
	'./BaseController',
	'sap/ui/model/json/JSONModel',
	'sap/ui/Device',
	'com/forex/app/model/formatter'
], function (BaseController, JSONModel, Device, formatter) {
	"use strict";
	return BaseController.extend("com.forex.app.controller.Home", {
		formatter: formatter,

		onInit: function () {
			
			
		},
		initSampleDataModel:async function(){
			let url=`${window.terminalurl}/users/current/accounts/${window.accountid}/account-information`;
			let result =await axios.get(url);
		}
		
	});
});