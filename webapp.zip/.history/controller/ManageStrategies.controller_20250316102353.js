

sap.ui.define([
    'sap/ui/core/library',
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (coreLibrary,BaseController, JSONModel) {
    "use strict";

    
    

    return BaseController.extend("com.forex.app.controller.History", {
        onInit: function () {
        
            // Load JSON data from file and set it as the model
            this.initSampleDataModel();
        
			

        },
        handleEditStategy :function(oEvent){

            let spath =oEvent.getSource().getBindingContext("managestrategies").getPath();
			let strategy=sap.ui.getCore().getModel("managestrategies").getProperty(spath);
            sap.ui.getCore().getModel("managestrategies").setProperty("/strategy",strategy);

            var oView = this.getView();
			if (!this.oEditStrategy) {
				this.oEditStrategy = this.loadFragment({
					name: "com.forex.app.fragment.EditAccount",
					controller: this
				});
			}
			this.oEditStrategy.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oEditStrategyDialog = oDialog;
				this.oEditStrategyDialog.open();


			}.bind(this));

        },

        closeEditStrategy: function(){
            oEditStrategy
        },
        initSampleDataModel :async function(){
            let strategies=await axios.get(`${window.copyfactoryurl}/users/current/configuration/strategies`);

            for(let i=0;i<strategies.data.length;i++){
                let strategy =strategies.data[i];
                strategy.symbols=[];
                if(strategy.symbolFilter && strategy.symbolFilter.included){
                    for(let j=0;j<strategy.symbolFilter.included.length;j++){
                        strategy.symbols.push({
                            "symbol":strategy.symbolFilter.included[j]
                        })
                    }

                }

            }

            sap.ui.getCore().getModel("managestrategies").setProperty("/strategies",strategies.data)
	
        }


        

     
    

        


        
    });
});