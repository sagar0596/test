

sap.ui.define([
    'sap/ui/core/library',
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (coreLibrary,BaseController, JSONModel) {
    "use strict";

    
    

    return BaseController.extend("com.forex.app.controller.History", {
        onInit: function () {
        
            // Load JSON data from file and set it as the model
            this.initSampleDataModel();
            this.getAllAccountsList();
			

            // Log the model data
           // console.log("Model Data:", oModel.getData());
        },

        

        getAllAccountsList:async function(){

            let accounts=(await axios.get("/users/current/accounts")).data;

            accounts=[{
                "name":"All Accounts",
                "_id":"ALL_ACCOUNTS"
            }].concat(accounts)


            sap.ui.getCore().getModel("history").setProperty("/allaccounts",accounts);

        },
    

        


        
    });
});