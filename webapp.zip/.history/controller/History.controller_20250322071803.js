

sap.ui.define([
    'sap/ui/core/library',
    './BaseController',
   
    "sap/ui/model/json/JSONModel",
    	'sap/ui/core/date/UI5Date'
], function (coreLibrary,BaseController, JSONModel,UI5Date) {
    "use strict";

    
    

    return BaseController.extend("com.forex.app.controller.History", {
        onInit: function () {
            this.selectedAccountID=`${window.accountid}`;
           
            sap.ui.getCore().getModel("history").setProperty("/search",{});
			
            sap.ui.getCore().getModel("history").setProperty("/search/accountid",`${window.accountid}`);

            

// Subtract one day to get yesterday's date
//const today = new Date();
const today = new Date();
today.setDate(today.getDate());

// Set the start of today (00:00:00)
const startOfToday = new Date(today);
startOfToday.setHours(0, 0, 0, 0); // Midnight

// Set the end of today (23:59:59)
const endOfToday = new Date(today);
endOfToday.setHours(23, 59, 59, 999); 


            sap.ui.getCore().getModel("history").setProperty("/search/date",{
                "operator":"TODAY",
                "values":[startOfToday,endOfToday]

            })

            this.date={
                "operator":"TODAY",
                "values":[startOfToday,endOfToday]

            }


            // Load JSON data from file and set it as the model
            this.initSampleDataModel();
            this.getAllAccountsList();
			

            // Log the model data
           // console.log("Model Data:", oModel.getData());
        },

        

       
        handleAccountChange:function(oEvent){
            let ValueState = coreLibrary.ValueState
                var oValidatedComboBox = oEvent.getSource(),
                    sSelectedKey = oValidatedComboBox.getSelectedKey(),
                    sValue = oValidatedComboBox.getValue();
                    let aFilteredValue= sap.ui.getCore().getModel('history').oData.allaccounts.filter((a)=>a._id==sSelectedKey);
                if(aFilteredValue.length==0){
                    sap.ui.getCore().getModel("history").setProperty("/search/accountid",this.selectedAccountID);
                    return;
                }
    
                if (!sSelectedKey && sValue) {
                    oValidatedComboBox.setValueState(ValueState.Error);
                    oValidatedComboBox.setValueStateText("Please enter a valid Account!");
                } else {
                 sap.ui.getCore().getModel("history").setProperty("/search/accountid",sSelectedKey);
                 this.selectedAccountID=sSelectedKey;   
                 oValidatedComboBox.setValueState(ValueState.None);
                    this.initSampleDataModel()
                }
               
           
        },

        getAllAccountsList:async function(){

            let accounts=(await axios.get("/users/current/accounts")).data;

            accounts=[{
                "name":"All Accounts",
                "_id":"ALL_ACCOUNTS"
            }].concat(accounts)


            sap.ui.getCore().getModel("history").setProperty("/allaccounts",accounts);

        },
        onDateChange:function(oEvent){
            if(oEvent.getParameter("valid")){
                let value = oEvent.getParameter("value");
                debugger;
                if(value){
                    let aDateRangerValues =sap.m.DynamicDateRange.toDates(oEvent.getParameter("value"));
                  
                    this.date=sap.ui.getCore().getModel("history").getProperty("/search/date");
                    this.date.values=aDateRangerValues;
                    sap.ui.getCore().getModel("history").setProperty("/search/date/values",aDateRangerValues);
                    this.initSampleDataModel();
    
                }else{
                    sap.ui.getCore().getModel("history").setProperty("/search/date",this.date);
    
                }
               


            }
        },

        





        initSampleDataModel: async function() {

            let accounts=await axios.get("/users/current/accounts");
            let searchAccount=sap.ui.getCore().getModel("history").getProperty("/search/accountid")
			   let promise=[];
               let historydealPromies=[];
				for(let i=0;i<accounts.data.length;i++){
                    let account=accounts.data[i];
                    let accountid=account._id;
 
                    if(searchAccount && (searchAccount==account._id ||searchAccount=="ALL_ACCOUNTS" )){
                        let aDateRangerValues =sap.ui.getCore().getModel("history").getProperty("/search/date/values");
                        let fromDate=aDateRangerValues[0].toISOString();
                        let toDate=aDateRangerValues[1].toISOString();
                      //  promise.push(this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/history-orders/time/${fromDate}/${toDate}`));
                        historydealPromies.push(this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/history-deals/time/${fromDate}/${toDate}`));
                    }

				}
		//	let orderresult =await Promise.all(promise);
            let result =await Promise.all(historydealPromies);
            debugger;
            //let results=this.prepareData(orderresult[0],dealsresult[0])
            let finalresult=[];
            for(let i=0;i<result.length;i++){
                let account=null;
                if(searchAccount &&searchAccount=="ALL_ACCOUNTS"){
                    account=accounts.data[i];
                }else if(searchAccount &&searchAccount!="ALL_ACCOUNTS"){
                    accounts.data.filter((a)=>a._id==searchAccount)
                }
                 
                
                account.closeButton=false;
                let accountPositions=[];
                for(let j=0;j<result[i].length;j++){
                 delete account["symbol"];
                 delete account["type"];
                 result[i][j]["accountid"]=account["_id"]; 
                  let date   = new Date( result[i][j]["time"]); 
                     result[i][j]["time"] = 
                ("00" + (date.getMonth() + 1)).slice(-2) 
                + "/" + ("00" + date.getDate()).slice(-2) 
                + "/" + date.getFullYear() + " " 
                + ("00" + date.getHours()).slice(-2) + ":" 
                + ("00" + date.getMinutes()).slice(-2) 
                + ":" + ("00" + date.getSeconds()).slice(-2);
                result[i][j]["closeButton"]=true; 
                accountPositions.push( result[i][j]);

                }
                account["accounts"]=accountPositions;
                finalresult.push(account);
            }

            sap.ui.getCore().getModel("history").setProperty("/history",{});
            sap.ui.getCore().getModel("history").setProperty("/history/accounts",finalresult);

            let historyDealsResult =await Promise.all(historydealPromies);



		},

        


        
    });
});