sap.ui.define([
	"sap/ui/core/library",
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"./model/models",
	"sap/ui/core/routing/History",
	"sap/ui/Device",
	"sap/ui/model/resource/ResourceModel",
	 "com/forex/app/reuse/js/index"
], function(library, UIComponent,JSONModel, models, History, Device) {
	

	return UIComponent.extend("com.forex.app.Component", {


		metadata: {
			manifest: "json",
			interfaces: [library.IAsyncContentCreation]
		},

		init: function () {

			window.metatoken="eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI5MGU3OWUyYjJjOWFhNjQwOTdmODgxOTc4MTc2ZGFmOCIsImFjY2Vzc1J1bGVzIjpbeyJpZCI6InRyYWRpbmctYWNjb3VudC1tYW5hZ2VtZW50LWFwaSIsIm1ldGhvZHMiOlsidHJhZGluZy1hY2NvdW50LW1hbmFnZW1lbnQtYXBpOnJlc3Q6cHVibGljOio6KiJdLCJyb2xlcyI6WyJyZWFkZXIiLCJ3cml0ZXIiXSwicmVzb3VyY2VzIjpbIio6JFVTRVJfSUQkOioiXX0seyJpZCI6Im1ldGFhcGktcmVzdC1hcGkiLCJtZXRob2RzIjpbIm1ldGFhcGktYXBpOnJlc3Q6cHVibGljOio6KiJdLCJyb2xlcyI6WyJyZWFkZXIiLCJ3cml0ZXIiXSwicmVzb3VyY2VzIjpbIio6JFVTRVJfSUQkOioiXX0seyJpZCI6Im1ldGFhcGktcnBjLWFwaSIsIm1ldGhvZHMiOlsibWV0YWFwaS1hcGk6d3M6cHVibGljOio6KiJdLCJyb2xlcyI6WyJyZWFkZXIiLCJ3cml0ZXIiXSwicmVzb3VyY2VzIjpbIio6JFVTRVJfSUQkOioiXX0seyJpZCI6Im1ldGFhcGktcmVhbC10aW1lLXN0cmVhbWluZy1hcGkiLCJtZXRob2RzIjpbIm1ldGFhcGktYXBpOndzOnB1YmxpYzoqOioiXSwicm9sZXMiOlsicmVhZGVyIiwid3JpdGVyIl0sInJlc291cmNlcyI6WyIqOiRVU0VSX0lEJDoqIl19LHsiaWQiOiJtZXRhc3RhdHMtYXBpIiwibWV0aG9kcyI6WyJtZXRhc3RhdHMtYXBpOnJlc3Q6cHVibGljOio6KiJdLCJyb2xlcyI6WyJyZWFkZXIiLCJ3cml0ZXIiXSwicmVzb3VyY2VzIjpbIio6JFVTRVJfSUQkOioiXX0seyJpZCI6InJpc2stbWFuYWdlbWVudC1hcGkiLCJtZXRob2RzIjpbInJpc2stbWFuYWdlbWVudC1hcGk6cmVzdDpwdWJsaWM6KjoqIl0sInJvbGVzIjpbInJlYWRlciIsIndyaXRlciJdLCJyZXNvdXJjZXMiOlsiKjokVVNFUl9JRCQ6KiJdfSx7ImlkIjoiY29weWZhY3RvcnktYXBpIiwibWV0aG9kcyI6WyJjb3B5ZmFjdG9yeS1hcGk6cmVzdDpwdWJsaWM6KjoqIl0sInJvbGVzIjpbInJlYWRlciIsIndyaXRlciJdLCJyZXNvdXJjZXMiOlsiKjokVVNFUl9JRCQ6KiJdfSx7ImlkIjoibXQtbWFuYWdlci1hcGkiLCJtZXRob2RzIjpbIm10LW1hbmFnZXItYXBpOnJlc3Q6ZGVhbGluZzoqOioiLCJtdC1tYW5hZ2VyLWFwaTpyZXN0OnB1YmxpYzoqOioiXSwicm9sZXMiOlsicmVhZGVyIiwid3JpdGVyIl0sInJlc291cmNlcyI6WyIqOiRVU0VSX0lEJDoqIl19LHsiaWQiOiJiaWxsaW5nLWFwaSIsIm1ldGhvZHMiOlsiYmlsbGluZy1hcGk6cmVzdDpwdWJsaWM6KjoqIl0sInJvbGVzIjpbInJlYWRlciJdLCJyZXNvdXJjZXMiOlsiKjokVVNFUl9JRCQ6KiJdfV0sImlnbm9yZVJhdGVMaW1pdHMiOmZhbHNlLCJ0b2tlbklkIjoiMjAyMTAyMTMiLCJpbXBlcnNvbmF0ZWQiOmZhbHNlLCJyZWFsVXNlcklkIjoiOTBlNzllMmIyYzlhYTY0MDk3Zjg4MTk3ODE3NmRhZjgiLCJpYXQiOjE3NDE3MDY0ODcsImV4cCI6MTc0OTQ4MjQ4N30.b-9yZxQfb7CTfTaPfEPqLXRKa8Px2CzsdJ4xW5lqhNU1GqyWl-f83wU2_XyViIzbqW6PFwXJbDk-5cT2i-RT7-eu4vyi0ety47dVb92oNYqzEZPFxVFG_TZpl32Yv1ga487_Z5PrxhtuzfQNEZE1hmNXaF_PIdAAbyA1ea0We8xpDxQVJrXmRW2t1VAyB3SbviK6jzP9miyCkPJV8b88D7_yFp5C9rS0F_VHZzP6bNjV2C1glsM1-kkc3HGPHkrcoKK2nogtWb_cHqASs2psmiqCeDYVqmgDu62AAlC2eVft7wOdtTTyz75u0wQqFKqp_3D6lWPZJ7guOWBFg_UAXJsm7KRwAHYrXJxhkVgLo55z52FiOZxkG3X8wVyEGrPnBKmkq0Fs06rsNcSHJMDMt9d-fQufYNCJ4gv45NhU3RBlzqtmPCnINl2MH2kJiSb_A5RUoimOS7uQyFUGdzUvvuqzbre3nG7cOUTfJt55Ebb6VwDxbFr322si3qHLnbGfq1L0apUqgJK6lyKfsro0yXigbhliiakacG6yVjn9qALBkG6r17YU5SvWu5SVKa0kzk-nGFw6M07SRAxEU4B6B5R8hFYFGjyJj5yp2xiefPbkPM8fChL-vK4rS8qnkk2Xy27rfCvSfGZ7duAd4jJhbYw3t8L7KVUE0shNZJ4DMPg";
			//window.api = new MetaApi.default(metatoken);
			window.accountid="1e0735e9-145b-4a80-bace-f76a2544a634";
			
		//	window.metaStats = new MetaApi.MetaStats(metatoken);
			window.terminalurl="https://mt-client-api-v1.london.agiliumtrade.ai";
			window.copyfactoryurl="https://copyfactory-api-v1.london.agiliumtrade.ai";

			axios.defaults.baseURL = "https://mt-provisioning-api-v1.agiliumtrade.agiliumtrade.ai";
			axios.defaults.headers.common['auth-token'] = `${metatoken}`;

		
			
			let oAppModel = new JSONModel({
				accounts: []
				
			  });
		
			 
			  sap.ui.getCore().setModel(oAppModel,"mts_accounts")
this.setModel(oAppModel,"mts_accounts");


let oWatchList = new JSONModel({
	accounts: []
	
  });

 
  sap.ui.getCore().setModel(oWatchList,"watchlist")
this.setModel(oWatchList,"watchlist");


let oHistory = new JSONModel({
	history: []
	
  });

 
  sap.ui.getCore().setModel(oHistory,"history")
this.setModel(oHistory,"history");


let oPositions = new JSONModel({
	positions: []
	
  });

 
  sap.ui.getCore().setModel(oPositions,"positions")
this.setModel(oPositions,"positions");


			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// create the views based on the url/hash
			this.getRouter().initialize();
		},

		myNavBack: function () {
			var oHistory = History.getInstance();
			var oPrevHash = oHistory.getPreviousHash();
			if (oPrevHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("masterSettings", {}, true);
			}
		},

		getContentDensityClass: function () {
			if (!this._sContentDensityClass) {
				if (!Device.support.touch){
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		}
	});
});