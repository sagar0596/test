import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js';
import { createUserWithEmailAndPassword, getAuth, onAuthStateChanged, sendEmailVerification, sendPasswordResetEmail, signInWithEmailAndPassword, signOut, } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js';
import { firebaseConfig } from './config.js';
initializeApp(firebaseConfig);
var auth = getAuth();
// Listening for auth state changes.
onAuthStateChanged(auth, function (user) {
    debugger;
     if (user) {
       // User is signed in.
       debugger;
     } else {
        debugger;
     }
    
});
