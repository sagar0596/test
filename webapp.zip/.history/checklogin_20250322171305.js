import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js';
import { createUserWithEmailAndPassword, getAuth, onAuthStateChanged, sendEmailVerification, sendPasswordResetEmail, signInWithEmailAndPassword, signOut, } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js';
import { firebaseConfig } from './config.js';
initializeApp(firebaseConfig);
var auth = getAuth();
// Listening for auth state changes.
onAuthStateChanged(auth, function (user) {
     verifyEmailButton.disabled = true;
     if (user) {
       // User is signed in.
       const displayName = user.displayName;
       const email = user.email;
       const emailVerified = user.emailVerified;
       const photoURL = user.photoURL;
       const isAnonymous = user.isAnonymous;
       const uid = user.uid;
       const providerData = user.providerData;
       signInStatus.textContent = 'Signed in';
       signInButton.textContent = 'Sign out';
       accountDetails.textContent = JSON.stringify(user, null, '  ');
       if (!emailVerified) {
         verifyEmailButton.disabled = false;
       }
     } else {
       // User is signed out.
       signInStatus.textContent = 'Signed out';
       signInButton.textContent = 'Sign in';
       accountDetails.textContent = 'null';
     }
     signInButton.disabled = false;
});
signInButton.addEventListener('click', toggleSignIn, false);
signUpButton.addEventListener('click', handleSignUp, false);
verifyEmailButton.addEventListener('click', sendVerificationEmailToUser, false);
passwordResetButton.addEventListener('click', sendPasswordReset, false);
