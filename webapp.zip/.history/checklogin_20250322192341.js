import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js';
import { createUserWithEmailAndPassword, getAuth, onAuthStateChanged, sendEmailVerification, sendPasswordResetEmail, signInWithEmailAndPassword, signOut, } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js';
import { firebaseConfig } from './config.js';

import {getFirestore ,getDocs,collection ,getDoc,doc} from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js';


const app =initializeApp(firebaseConfig);
window.auth = getAuth();
// Listening for auth state changes.
onAuthStateChanged(auth, async function (user) {
   
     if (user) {
        debugger;
      window.username=user.email;
      window.uid=user.uid
      const db = getFirestore(app);

      const userId = auth.currentUser.uid;
      const userDoc = await getDoc(doc(db, "users", userId));

     let userdata= userDoc.data();
     window.accountid=userdata.aid;
     window.metatoken=""
      debugger;

     } else {
        debugger;
     }
    
});
window.signOut=signOut;
