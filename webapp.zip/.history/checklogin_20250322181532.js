import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js';
import { createUserWithEmailAndPassword, getAuth, onAuthStateChanged, sendEmailVerification, sendPasswordResetEmail, signInWithEmailAndPassword, signOut, } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js';
import { firebaseConfig } from './config.js';

import {getFirestore  } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js';


initializeApp(firebaseConfig);
window.auth = getAuth();
// Listening for auth state changes.
onAuthStateChanged(auth, function (user) {
   
     if (user) {
        debugger;
      window.username=user.email;
      const db = getFirestore(app);
     } else {
        debugger;
     }
    
});
window.signOut=signOut;
