

sap.ui.define([
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
    "use strict";

    return BaseController.extend("com.forex.app.controller.Pending", {
        onInit: function () {
            // Load JSON data from file and set it as the model
            const router = this.getOwnerComponent().getRouter();
            router.getRoute("pending").attachMatched(this._onRouteMatched, this);
			

            // Log the model data
           // console.log("Model Data:", oModel.getData());
        },

        _onRouteMatched: function () {
            this.initSampleDataModel();
        },

        getStategyName:function(stategyid){
            if(!stategyid){
                return;
            }
            let aStategies=sap.ui.getCore().getModel("pending").getProperty("/strategies");
            let filterredData =aStategies.filter((a)=>a._id==stategyid);
            if(filterredData.length>0){
                return filterredData[0].name
            }else{
                return stategyid;
            }
    
        },



        initSampleDataModel: async function() {
            let strategies=await axios.get(`${window.copyfactoryurl}/users/current/configuration/strategies`);

          

            sap.ui.getCore().getModel("pending").setProperty("/strategies",strategies.data)



let pendingordersurl=`${window.terminalurl}/users/current/accounts/${window.accountid}/orders`;
let pendingorders = await this.fetchAllData([pendingordersurl]);
		
//l//et strategiesArray=[]

sap.ui.getCore().getModel("pending").setProperty("/orders",pendingorders[0]);


		},
        modifyPendingOrder:  function(oEvent){

            let spath =oEvent.getSource().getBindingContext("pending").getPath();
			let order=sap.ui.getCore().getModel("pending").getProperty(spath);
			sap.ui.getCore().getModel("pending").setProperty("/modify",order);
			
			var oView = this.getView();
			if (!this.oModifyPendingOrder) {
				this.oModifyPendingOrder = this.loadFragment({
					name: "com.forex.app.fragment.ModifyPendingOrder",
					controller: this
				});
			}
			this.oModifyPendingOrder.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oModifyPendingOrderDialog = oDialog;
				this.oModifyPendingOrderDialog.open();


			}.bind(this));

			


        },
        closeModifyPendingOrderDialog:function(){
			this.oModifyPendingOrderDialog.close();
			
		},

        placeModifiedOrder:async function(){
            let order=sap.ui.getCore().getModel("pending").getProperty("/modify");
            let payload={};
            payload.actionType="ORDER_MODIFY";
            payload.orderId=order.id;
            if(order.openPrice){
                payload.openPrice=parseFloat(order.openPrice);

            }
            if(order.stopLoss){
                payload.stopLoss=parseFloat(order.stopLoss);

            }
            if(order.takeProfit){
                payload.takeProfit=parseFloat(order.takeProfit);

            }

            await this.handleTradingErrors(null,payload,this.closeModifyPendingOrderDialog,null,this);

        this.initSampleDataModel();
            
			
        },
        cancelOrder:async function(oEvent){
            let spath =oEvent.getSource().getBindingContext("pending").getPath();
			let order=sap.ui.getCore().getModel("pending").getProperty(spath);
            let payload={};

			payload["actionType"]= "ORDER_CANCEL",
            payload["orderId"]=order.id;

            await this.handleTradingErrors(null,payload,null,null,this);

           this.initSampleDataModel();

        }

    });
});