

sap.ui.define([
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
    "use strict";

    return BaseController.extend("com.forex.app.controller.Pending", {
        onInit: function () {
            // Load JSON data from file and set it as the model
            const oJSONModel = this.initSampleDataModel();
			

            // Log the model data
           // console.log("Model Data:", oModel.getData());
        },
        initSampleDataModel: async function() {



let pendingordersurl=`${window.terminalurl}/users/current/accounts/${window.accountid}/orders`;
let pendingorders = await this.fetchAllData([pendingordersurl]);
		
//l//et strategiesArray=[]

sap.ui.getCore().getModel("pending").setProperty("/orders",pendingorders[0]);


		},
        modifyPendingOrder:  function(oEvent){

            let spath =oEvent.getSource().getBindingContext("pending").getPath();
			let order=sap.ui.getCore().getModel("pending").getProperty(spath);
			sap.ui.getCore().getModel("pending").setProperty("/modify",order);
			
			var oView = this.getView();
			if (!this.oModifyPendingOrder) {
				this.oModifyPendingOrder = this.loadFragment({
					name: "com.forex.app.fragment.ModifyPendingOrder",
					controller: this
				});
			}
			this.oModifyPendingOrder.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oModifyPendingOrderDialog = oDialog;
				this.oModifyPendingOrderDialog.open();


			}.bind(this));

			


        },
        closeModifyPendingOrderDialog:function(){
			this.oModifyPendingOrderDialog.close();
			
		},

        placeModifiedOrder:function(){
            let order=sap.ui.getCore().getModel("pending").getProperty("/modify");
            let payload={};
            payload.actionType="ORDER_MODIFY";
            payload.orderId=order.id;
            if(order.openPrice){
                payload.openPrice=parseFloat(order.openPrice);

            }
            if(order.stopLoss){
                payload.stopLoss=parseFloat(order.stopLoss);

            }
            if(order.takeProfit){
                payload.takeProfit=parseFloat(order.takeProfit);

            }

            let url=`${window.terminalurl}/users/current/accounts/${window.accountid}/trade`

            axios.post(url,payload)
             this.closeModifyPendingOrderDialog();

            
			
        },
        cancelOrder:function(oEvent){
            let spath =oEvent.getSource().getBindingContext("pending").getPath();
			let order=sap.ui.getCore().getModel("pending").getProperty(spath);
            let payload={};

			payload["actionType"]= "ORDER_CANCEL",
            payload["orderId"]=order.id;

            let url=`${window.terminalurl}/users/current/accounts/${window.accountid}/trade`

            axios.post(url,payload)

        }

    });
});