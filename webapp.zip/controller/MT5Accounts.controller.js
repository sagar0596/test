sap.ui.define([
	'./BaseController',
	"sap/base/Log",
	"sap/ui/table/library",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat",
	"sap/ui/thirdparty/jquery",
	"sap/ui/core/date/UI5Date"
], function (BaseController, Log, library, Controller, MessageToast, JSONModel, DateFormat, jQuery, UI5Date) {
	"use strict";

	const SelectionBehavior = library.SelectionBehavior;
	return BaseController.extend("com.forex.app.controller.MT5Accounts", {
		onInit: function () {
			this.initSampleDataModel();


		},
		onAfterRendering: function () {


		},
		// Function to fetch data with error handling
 /*fetchDataWithErrorHandling : async function(url)  {
   
        const response = await axios.get(url);
        return response.data; // Return the data from the response
   
},

// Main function to make parallel API calls
 fetchAllData : async function(apiUrls) {
    
        // Create an array of promises with error handling
        const promises = apiUrls.map(url => this.fetchDataWithErrorHandling(url));

        // Use Promise.all to make parallel calls
        const results = await Promise.all(promises);
		return results;

       
   
},*/
getAllStrategies:async function(){
	let strategies=await axios.get(`${window.copyfactoryurl}/users/current/configuration/strategies`);
	return strategies.data;
				

},


		initSampleDataModel: async function () {
			try{
			 	let accounts=await axios.get("/users/current/accounts");
				let subscribers=await axios.get(`${window.copyfactoryurl}/users/current/configuration/subscribers`);
				let allStrategies= await this.getAllStrategies();
				sap.ui.getCore().getModel("mts_accounts").setProperty("/strategies",allStrategies);
				const strategyMap = new Map(allStrategies.map(item => [item._id, item.name]));
				
				
				//let accounturls=[];
				let accounttermialurl=[];
				//let strategyurl=[];
				for(let i=0;i<accounts.data.length;i++){
					let account=accounts.data[i];
					let accountid=account._id;
				//	accounturls.push(`/users/current/accounts/${accountid}`);
					accounttermialurl.push(`${window.terminalurl}/users/current/accounts/${accountid}/account-information`)
				//	strategyurl.push(`${window.copyfactoryurl}/users/current/configuration/subscribers/${accountid}`)
					
				}
				//let accountresultsP = this.fetchAllData(accounturls);
				let accounttermialurlresultP= this.fetchAllData(accounttermialurl);
		// 		let strategyurlresultP= this.fetchAllData(strategyurl);
			//	let accountresult= await accountresultsP;
				let accounttermialurlresult=await accounttermialurlresultP;
			//	let stategyurlresult=await strategyurlresultP;
				let results=[];
				for(let i=0;i<accounts.data.length;i++){
					let data=accounttermialurlresult[i];
					data.name=accounts.data[i].name;
					data.account_id=accounts.data[i]._id;
					data.state=accounts.data[i].state;

				//	data.strategies=[];
					for(let j=0;j<subscribers.data.length;j++){
						if(data.account_id==subscribers.data[j]._id){
							data.subscriptions=subscribers.data[j].subscriptions;
							data.strategies =[];
							for(let k=0;k<subscribers.data[j].subscriptions.length;k++){
								data.strategies.push(subscribers.data[j].subscriptions[k].strategyId);
								/*data.strategies.push({
									"strategyid":subscribers.data[j].subscriptions[k].strategyId,
									"strategyname":strategyMap.get(subscribers.data[j].subscriptions[k].strategyId)
								})*/
	
							}
							
						}
					}
					data.server=accounts.data[i].server;
					//data.tags=accountresult[i].tags;
				//	data.strategies=stategyurlresult[i].subscriptions;
					results.push(data);

				}
				sap.ui.getCore().getModel("mts_accounts").setProperty("/accounts", results);

			}catch(err){
				console.error(err);

			}




		},
		handleEditAccount :function(oEvent){
			let spath =oEvent.getSource().getBindingContext("mts_accounts").getPath();
			let account=sap.ui.getCore().getModel("mts_accounts").getProperty(spath);
			
			let accountdata=Object.assign({}, account);
			if(accountdata.state="DEPLOYED"){
				accountdata.isdeployed=true;

			}else{
				accountdata.isdeployed=false;

			}
			
			sap.ui.getCore().getModel("mts_accounts").setProperty("/account",accountdata);

			var oView = this.getView();
			if (!this.oEditAccount) {
				this.oEditAccount = this.loadFragment({
					name: "com.forex.app.fragment.EditAccount",
					controller: this
				});
			}
			this.oEditAccount.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oEditAccountDialog = oDialog;
				this.oEditAccountDialog.open();


			}.bind(this));

		},

		handleAddAccount: function(){

			
			sap.ui.getCore().getModel("mts_accounts").setProperty("/addaccount",{});

			var oView = this.getView();
			if (!this.oAddAccount) {
				this.oAddAccount = this.loadFragment({
					name: "com.forex.app.fragment.AddAccount",
					controller: this
				});
			}
			this.oAddAccount.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oAddAccountDialog = oDialog;
				this.oAddAccountDialog.open();


			}.bind(this));

		},
		onSaveAccountChanges:async function(){
			

			let allStategies =sap.ui.getCore().getModel("mts_accounts").getProperty("/strategies");
				
				
			let accountdata=sap.ui.getCore().getModel("mts_accounts").getProperty("/account");
			let payload={};
			payload.name=accountdata.name;
			payload.subscriptions=[];
			
			for(let i=0;i<accountdata.strategies.length;i++){
			    let stategyid=accountdata.strategies[i];
				let filteredSategy=allStategies.filter((a)=>a._id==stategyid);
				filteredSategy = JSON.parse( JSON.stringify(filteredSategy[0]));
				let subpayload={};
				subpayload.strategyId=filteredSategy._id;
				subpayload.skipPendingOrders=filteredSategy.skipPendingOrders;
				subpayload.reverse=filteredSategy.reverse;
				subpayload.symbolFilter=filteredSategy.symbolFilter;
				subpayload.tradeSizeScaling=filteredSategy.tradeSizeScaling;
				subpayload.copyStopLoss=filteredSategy.copyStopLoss;
				subpayload.copyTakeProfit=filteredSategy.copyTakeProfit;
				payload.subscriptions.push(subpayload);

			}
			let updatestrategyurl=`${window.copyfactoryurl}/users/current/configuration/subscribers/${accountdata.account_id}`;
            await axios.put(updatestrategyurl,payload);

			if(accountdata.state=="DEPLOYED" && !accountdata.isdeployed){

				await axios.put(`/users/current/accounts/${accountdata.account_id}/undeploy`);

			}else if(accountdata.state=="UNDEPLOYED" && accountdata.isdeployed ){
				await axios.put(`/users/current/accounts/${accountdata.account_id}/deploy`);

			}

			this.initSampleDataModel();
			this.onCancelAccountChanges();
			this.initSampleDataModel();
           
  

		},

		onCancelAccountChanges: function(){
			this.oEditAccountDialog.close();
		},

		onAddAccount:async function(){
		
			let data =sap.ui.getCore().getModel("mts_accounts").getProperty("/addaccount");
			data.magic=0;
			
			data.platform="mt5";
			data.copyFactoryRoles=["SUBSCRIBER"];
			
			
			data.region="london";
			data.baseCurrency="USD";
			data.type= "cloud-g2";
			data.metastatsApiEnabled= false;
			data.riskManagementApiEnabled= false;
			data.reliability="high";
			data.quoteStreamingIntervalInSeconds= 2.5;
			data.resourceSlots=1;
			data.copyFactoryResourceSlots= 1;
			debugger;

			const headers = {
				'transaction-id':this.generateTranscationid(),
				
			  }
			const response = await axios.post("/users/current/accounts",data,{
				headers: headers
			  });
			  this.onCancelAddAccount();

			

		},

		 generateTranscationid : function(){
			const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
			let result = '';
			const length = 32;
			for (let i = 0; i < length; i++) {
				const randomIndex = Math.floor(Math.random() * characters.length);
				result += characters[randomIndex];
			}
			return result;
		},

		onCancelAddAccount: function(){
			this.oAddAccountDialog.close();
		},
		
		

		onSelectionModeChange: function (oEvent) {
			if (oEvent.getParameter("selectedItem").getKey() === "All") {
				MessageToast.show("selectionMode:All is deprecated. Please select another one.");
				return;
			}
			const oTable = this.byId("table1");
			oTable.setSelectionMode(oEvent.getParameter("selectedItem").getKey());
		},

		onBehaviourModeChange: function (oEvent) {
			const oTable = this.byId("table1");
			oTable.setSelectionBehavior(oEvent.getParameter("selectedItem").getKey());
		},

		onSwitchChange: function (oEvent) {
			const oTable = this.byId("table1");
			oTable.setEnableSelectAll(oEvent.getParameter("state"));
		},

		

		

		onGetStrategies: async function (evt) {
			sap.ui.getCore().getModel("mts_accounts").getProperty("/all_stategies");
			
			let url=`${window.copyfactoryurl}/users/current/configuration/strategies`;
			const response = await axios.get(url);

			sap.ui.getCore().getModel("mts_accounts").setProperty("/all_stategies",response.data);
			
		},

		getContextByIndex: function (evt) {
			const oTable = this.byId("table1");
			const iIndex = oTable.getSelectedIndex();
			let sMsg;
			if (iIndex < 0) {
				sMsg = "no item selected";
			} else {
				sMsg = oTable.getContextByIndex(iIndex);
			}
			MessageToast.show(sMsg);
		},

		clearSelection: function (evt) {
			this.byId("table1").clearSelection();
		},

		formatAvailableToObjectState: function (bAvailable) {
			return bAvailable ? "Success" : "Error";
		},

		formatAvailableToIcon: function (bAvailable) {
			return bAvailable ? "sap-icon://accept" : "sap-icon://decline";
		},

		handleDeleteAccount:async function(oEvent){

			let spath =oEvent.getSource().getBindingContext("mts_accounts").getPath();
			let account=sap.ui.getCore().getModel("mts_accounts").getProperty(spath);
			await axios.delete(`/users/current/accounts/${account.account_id}`);


		},

		handleDetailsPress: function (oEvent) {
			MessageToast.show("Details for product with id " + this.getView().getModel().getProperty("ProductId", oEvent.getSource().getBindingContext()));
		}

	});

});