

sap.ui.define([
    'sap/ui/core/library',
    './BaseController',
   
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
], function (coreLibrary,BaseController, JSONModel,MessageBox) {
    "use strict";

    return BaseController.extend("com.forex.app.controller.Positions", {
        onInit: function () {
            // Load JSON data from file and set it as the model
            this.getAllAccountsList();
            this.initSampleDataModel(`${window.accountid}`);
            this.selectedAccountID=`${window.accountid}`;
            sap.ui.getCore().getModel("positions").setProperty("/search",{});
			
            sap.ui.getCore().getModel("positions").setProperty("/search/accountid",`${window.accountid}`);

            // Log the model data
           // console.log("Model Data:", oModel.getData());
        },
        handleAccountChange:function(oEvent){
            let ValueState = coreLibrary.ValueState
                var oValidatedComboBox = oEvent.getSource(),
                    sSelectedKey = oValidatedComboBox.getSelectedKey(),
                    sValue = oValidatedComboBox.getValue();
                let aFilteredValue= sap.ui.getCore().getModel('positions').oData.allaccounts.filter((a)=>a._id==sSelectedKey);
                if(aFilteredValue.length==0){
                    sap.ui.getCore().getModel("positions").setProperty("/search/accountid",this.selectedAccountID);
                    return;
                }

                if (!sSelectedKey && sValue) {
                    oValidatedComboBox.setValueState(ValueState.Error);
                    oValidatedComboBox.setValueStateText("Please enter a valid Account!");
                } else {
                 sap.ui.getCore().getModel("positions").setProperty("/search/accountid",sSelectedKey);
                 this.selectedAccountID=sSelectedKey;
                    oValidatedComboBox.setValueState(ValueState.None);
                    this.initSampleDataModel()

                }
           
        },
        handlePositionClose:async function(oEvent){
            debugger;
            let spath =oEvent.getSource().getBindingContext("positions").getPath();
            let parts=spath.split("/");
            if(parts.length>4){
                
                let openPosition=sap.ui.getCore().getModel("positions").getProperty(spath);
                let accountid=openPosition.accountid;
    
                let payload={};
                payload.actionType="POSITION_CLOSE_ID";
                payload.positionId=openPosition.id;
                payload.comment=openPosition.comment;
    
                await this.handleTradingErrors(accountid,payload,null,null,this);
                this.initSampleDataModel();


            }else{

        let accountDetails=sap.ui.getCore().getModel("positions").getProperty(spath);
        sap.ui.getCore().getModel("positions").setProperty("/account_close",accountDetails);

      
        let all = {
            "profit":0.0,
            "count":0,
            "id":"all",
            
            "text":"Close All"
        };
let all_profit ={
    "profit":0.0,
    "count":0,
    "id":"all_profit",
            "text":"Close All Profitable" 
};
let all_loss = {
    "profit":0.0,
    "count":0,
    "id":"all_loss",
            "text":"Close All Losing"
};
let all_buy = {
    "profit":0.0,
    "count":0,
    "id":"all_buy",
            "text":"Close All Buy"
};
let all_sell = {
    "profit":0.0,
    "count":0,
    "id":"all_sell",
            "text":"Close All Sell"
};

       
        for(let i=0;i<accountDetails.accounts.length;i++){
            let item =accountDetails.accounts[i];

            let profitValue =parseFloat( parseFloat(item.profit).toFixed(2));
            all.profit += parseFloat( parseFloat(profitValue).toFixed(2));
            all.profit=parseFloat(parseFloat(all.profit).toFixed(2))
            all.count +=1;
            if(profitValue<0){
                all_loss.profit += parseFloat(parseFloat(profitValue).toFixed(2));
                all_loss.profit=parseFloat(parseFloat(all_loss.profit).toFixed(2))
                all_loss.count +=1;

            }else{
                all_profit.profit += parseFloat(parseFloat(profitValue).toFixed(2));
                all_profit.profit=parseFloat(parseFloat(all_profit.profit).toFixed(2))
                all_profit.count +=1;

            }

            if(item.type=="POSITION_TYPE_BUY"){
                all_buy.profit += parseFloat(parseFloat(profitValue).toFixed(2));
                all_buy.profit=parseFloat(parseFloat(all_buy.profit).toFixed(2))
                all_buy.count +=1;
            }else{
                all_sell.profit += parseFloat(parseFloat(profitValue).toFixed(2));
                all_sell.profit=parseFloat(parseFloat(all_sell.profit).toFixed(2))
                all_sell.count +=1;
            }
            


        }


        let displayData=[all,all_profit,all_loss,all_buy,all_sell];

        sap.ui.getCore().getModel("positions").setProperty("/account_close_display",displayData);
        sap.ui.getCore().getModel("positions").setProperty("/selectedClose",{});
       
        var oView = this.getView();
        if (!this.oAccountClosePosition) {
            this.oAccountClosePosition = this.loadFragment({
                name: "com.forex.app.fragment.PositionClose",
                controller: this
            });
        }
        this.oAccountClosePosition.then(function (oDialog) {
            oView.addDependent(oDialog);
            this.oAccountClosePositionDialog = oDialog;
            this.oAccountClosePositionDialog.open();


        }.bind(this));

            }
        },

        onSelectedPositionClose:function(oEvent){
            let spath =oEvent.getParameter("listItem").getBindingContext("positions").getPath();
			let selectedClose=sap.ui.getCore().getModel("positions").getProperty(spath);
          
            sap.ui.getCore().getModel("positions").setProperty("/selectedClose",selectedClose);
       

        },

        handleSelectedClose:async function(){
            let data =sap.ui.getCore().getModel("positions").getProperty("/selectedClose");
            if(!data.id){
                return;
            }

            let id=data.id;
          
   debugger;
   let accountDetails= sap.ui.getCore().getModel("positions").getProperty("/account_close");

  let promise=[];
    for(let i=0;i<accountDetails.accounts.length;i++){
        let item =accountDetails.accounts[i];
        let accountid=item.accountid;
        let profit=parseFloat(item.profit);
    
        let payload={};
        payload.actionType="POSITION_CLOSE_ID";
        payload.positionId=item.id;
        payload.comment=item.comment;
     
        let url=`${window.terminalurl}/users/current/accounts/${accountid}/trade`
     
        
        if(id=="all"){
            promise.push(axios.post(url,payload));
        }
        else if(id=="all_profit" && profit>0){
            promise.push(axios.post(url,payload));
        }else if(id=="all_loss" && profit<0){
            promise.push(axios.post(url,payload));
        }else if(id=="all_buy" && item.type=="POSITION_TYPE_BUY"){
            promise.push(axios.post(url,payload));
        }else if(id=="all_sell" && item.type=="POSITION_TYPE_SELL"){
            promise.push(axios.post(url,payload));
        }
    


     }
     try{
        await Promise.all(promise);
        MessageBox.information("All Positions Closed");
        this.onCloseAccountCloseDialog();
        this.initSampleDataModel();
     }catch(err){
        MessageBox.information("Could Not Close All  Positions ");
     }

       
    },

        onCloseAccountCloseDialog:function(){
            this.oAccountClosePositionDialog.close();   
            this.getView().removeDependent(this.oAccountClosePositionDialog);

			this.oAccountClosePositionDialog.destroy();
			this.oAccountClosePosition=null;

            
        },

        handleParticalPositionClose:async function(oEvent){
           
			let openPosition=sap.ui.getCore().getModel("positions").getProperty("/pp");
            let accountid=openPosition.accountid;
            let payload={};
         
            payload.actionType="POSITION_PARTIAL";
            payload.positionId=openPosition.id;
            payload.comment=openPosition.comment;
            payload.volume=parseFloat(openPosition.volume);


            await this.handleTradingErrors(accountid,payload,this.closeParticalPositionDialog,null,this);
    
            this.initSampleDataModel();

        },

        closeParticalPositionDialog(){
            this.oParticalPositionDialog.close();

        },

        closeModifyPositionDialog(){
            this.oModifyPositionDialog .close();

        },

        openParticalCloseDialog:function(oEvent){

            let spath =oEvent.getSource().getBindingContext("positions").getPath();
			let openPosition=sap.ui.getCore().getModel("positions").getProperty(spath);
            openPosition = JSON.parse(JSON.stringify(openPosition));
            sap.ui.getCore().getModel("positions").setProperty("/pp",openPosition);

            var oView = this.getView();
            if (!this.oParticalPosition) {
				this.oParticalPosition = this.loadFragment({
					name: "com.forex.app.fragment.ParticalPosition",
					controller: this
				});
			}
			this.oParticalPosition.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oParticalPositionDialog = oDialog;
				this.oParticalPositionDialog.open();


			}.bind(this));

        },

        openModifyPostionDialog:function(oEvent){

            let spath =oEvent.getSource().getBindingContext("positions").getPath();
			let openPosition=sap.ui.getCore().getModel("positions").getProperty(spath);
            openPosition = JSON.parse(JSON.stringify(openPosition));
            sap.ui.getCore().getModel("positions").setProperty("/modify",openPosition);

            var oView = this.getView();
            if (!this.oModifyPosition) {
				this.oModifyPosition = this.loadFragment({
					name: "com.forex.app.fragment.ModifyPosition",
					controller: this
				});
			}
			this.oModifyPosition.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oModifyPositionDialog = oDialog;
				this.oModifyPositionDialog.open();


			}.bind(this));

        },
        handleHedgePosition:async function(){
            let openPosition=sap.ui.getCore().getModel("positions").getProperty("/hedge");

            let payload={};
            payload.actionType="POSITION_CLOSE_BY";
            payload.positionId=openPosition.id;
            payload.comment=openPosition.comment;
            let accountid=openPosition.accountid;

            let hedgeData=sap.ui.getCore().getModel("positions").getProperty("/hedgeEstimated")
            payload.closeByPositionId=hedgeData.id;
            await this.handleTradingErrors(accountid,payload,this.onCloseHedgeDialog,null,this);
    

            this.initSampleDataModel();

        },




        handleModifyPosition:async function(oEvent){
           
			let openPosition=sap.ui.getCore().getModel("positions").getProperty("/modify");

            let payload={};
            payload.actionType="POSITION_MODIFY";
            payload.positionId=openPosition.id;
         //   payload.comment=openPosition.comment;
            let accountid=openPosition.accountid;

            if(openPosition.stopLoss){
                payload.stopLoss=parseFloat(openPosition.stopLoss);

            }
            if(openPosition.takeProfit){
                payload.takeProfit=parseFloat(openPosition.takeProfit);

            }

            await this.handleTradingErrors(accountid,payload,this.closeModifyPositionDialog,null,this);
            this.initSampleDataModel();
    
        },


        prepareHedgePositionData: function(oEvent){
            debugger;
            let spath =oEvent.getSource().getBindingContext("positions").getPath();
			let openPosition=sap.ui.getCore().getModel("positions").getProperty(spath);
            sap.ui.getCore().getModel("positions").setProperty("/hedge",openPosition);
            
            let positionsForAccountPath =spath.substring(0,spath.lastIndexOf("/"));
            let allOpenPositionsForAccount=sap.ui.getCore().getModel("positions").getProperty(positionsForAccountPath);
            let filteredOppsitePosition=[];
            if(openPosition.type=="POSITION_TYPE_BUY"){
                filteredOppsitePosition= allOpenPositionsForAccount.filter((a)=>a.type=="POSITION_TYPE_SELL" && a.symbol==openPosition.symbol)

            }else{

                filteredOppsitePosition= allOpenPositionsForAccount.filter((a)=>a.type=="POSITION_TYPE_BUY" && a.symbol==openPosition.symbol)


            }
            let displaydata=[]
            for(let i=0;i<filteredOppsitePosition.length;i++){
                if(filteredOppsitePosition[i].type=="POSITION_TYPE_BUY"){

                    displaydata.push({
                        text:`Buy ${filteredOppsitePosition[i].volume} at ${filteredOppsitePosition[i].openPrice} P/L  ${filteredOppsitePosition[i].profit}`
                    })

                }else{
                    displaydata.push({
                        text:`Sell ${filteredOppsitePosition[i].volume} at ${filteredOppsitePosition[i].openPrice} P/L  ${filteredOppsitePosition[i].profit}`
                    })
                }


            }

            sap.ui.getCore().getModel("positions").setProperty("/hedgepositions",filteredOppsitePosition);
            sap.ui.getCore().getModel("positions").setProperty("/hedgepositionsdisplay",displaydata);
            
            let dialogTitle="";
            if(openPosition.type=="POSITION_TYPE_BUY"){
                dialogTitle=`Buy ${openPosition.symbol}  position close by` 
            }else{
                dialogTitle=`Sell ${openPosition.symbol}  position close by` 
            }
            sap.ui.getCore().getModel("positions").setProperty("/hedgedialogtitle",dialogTitle);
            var oView = this.getView();
            if (!this.oHedgePosition) {
				this.oHedgePosition = this.loadFragment({
					name: "com.forex.app.fragment.Hedge",
					controller: this
				});
			}
			this.oHedgePosition.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oHedgePositionDialog = oDialog;
				this.oHedgePositionDialog.open();


			}.bind(this));



        },

        formatByText :function(data){
            if(!data){
                return;
            }
            let profit=parseFloat(data.split("P/L")[1]);
            if(profit>0){
                return "Success";

            }else{
                return "Error";
            }


        },
        onCloseHedgeDialog:function(){
            this.oHedgePositionDialog.close();   
            this.getView().removeDependent(this.oHedgePositionDialog);

			this.oHedgePositionDialog.destroy();
			this.oHedgePosition=null;

            
        },
        getHedgeEstimateValue :function(data){
            if(data){
                let hedgedata=sap.ui.getCore().getModel("positions").getProperty("/hedge");
                let hedgeProfit=parseFloat(hedgedata.profit);
                let oppsitepositionprofit=parseFloat(data.profit);
                let total= parseFloat(hedgeProfit +oppsitepositionprofit);
                total=parseFloat(parseFloat(total).toFixed(2));
                return `Estimated P/L ${total}`
    

            }

        },

        getHedgeEstimateValueState :function(data){
            if(data){
                let hedgedata=sap.ui.getCore().getModel("positions").getProperty("/hedge");
                let hedgeProfit=parseFloat(hedgedata.profit);
                let oppsitepositionprofit=parseFloat(data.profit);
                let total= parseFloat(hedgeProfit +oppsitepositionprofit);
                total=parseFloat(parseFloat(total).toFixed(2));
              if(total>0){
                return "Success"
              }else{
                return "Error"
              }
    

            }

        },
        onHedgeSelectionChange :function(oEvent){
           let spath= oEvent.getParameter("listItem").getBindingContext("positions").getPath()
           let acutalDataPath=spath.replace('hedgepositionsdisplay','hedgepositions')
          let data= sap.ui.getCore().getModel("positions").getProperty(acutalDataPath);
          sap.ui.getCore().getModel("positions").setProperty("/hedgeEstimated",data);

            //let spath =oEvent.getSource().getBindingContext("positions").getPath();
			//let openPosition=sap.ui.getCore().getModel("positions").getProperty(spath);
       

        },
        getAllAccountsList:async function(){

            let accounts=(await axios.get("/users/current/accounts")).data;

            accounts=[{
                "name":"All Accounts",
                "_id":"ALL_ACCOUNTS"
            }].concat(accounts)


            sap.ui.getCore().getModel("positions").setProperty("/allaccounts",accounts);

        },


     
        initSampleDataModel: async function() {

            let accounts=await axios.get("/users/current/accounts");
            let searchAccount=sap.ui.getCore().getModel("positions").getProperty("/search/accountid")
			   let promise=[];
				for(let i=0;i<accounts.data.length;i++){
                    let account=accounts.data[i];
                    let accountid=account._id;
 
                    if(searchAccount && (searchAccount==account._id ||searchAccount=="ALL_ACCOUNTS" )){
                       
                        
                        promise.push(this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/positions?refreshTerminalState=true`));
                    }

				}
			let result =await Promise.all(promise);
            let finalresult=[];
            for(let i=0;i<result.length;i++){
                 
                let account=null;
                if(searchAccount &&searchAccount=="ALL_ACCOUNTS"){
                    account=accounts.data[i];
                }else if(searchAccount &&searchAccount!="ALL_ACCOUNTS"){
                    let filteredAccounts=accounts.data.filter((a)=>a._id==searchAccount);
                    account=filteredAccounts[0];
                }
                account.closeButton=false;
                let accountPositions=[];
                for(let j=0;j<result[i].length;j++){
                 delete account["symbol"];
                 delete account["type"];
                 result[i][j]["accountid"]=account["_id"]; 
                  let date   = new Date( result[i][j]["time"]); 
                     result[i][j]["time"] = 
                ("00" + (date.getMonth() + 1)).slice(-2) 
                + "/" + ("00" + date.getDate()).slice(-2) 
                + "/" + date.getFullYear() + " " 
                + ("00" + date.getHours()).slice(-2) + ":" 
                + ("00" + date.getMinutes()).slice(-2) 
                + ":" + ("00" + date.getSeconds()).slice(-2);
                result[i][j]["closeButton"]=true; 
                accountPositions.push( result[i][j]);

                }
                account["accounts"]=accountPositions;
                finalresult.push(account);
            }

            sap.ui.getCore().getModel("positions").setProperty("/positions",{});
            sap.ui.getCore().getModel("positions").setProperty("/positions/accounts",finalresult);


		},
    });
});