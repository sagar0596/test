sap.ui.define([
    './BaseController',
	"sap/base/Log",
	"sap/ui/table/library",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat",
	"sap/ui/thirdparty/jquery",
	"sap/ui/core/date/UI5Date",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/ui/core/library',
	"sap/m/MessageBox",
], function(BaseController,Log, library, Controller, MessageToast, JSONModel, DateFormat, jQuery, UI5Date,Filter,FilterOperator,coreLibrary,MessageBox) {
	"use strict";

	const SelectionBehavior = library.SelectionBehavior;
	const SelectionMode = library.SelectionMode;
	return BaseController.extend("com.forex.app.controller.WatchList", {
		onInit: function() {
			// set explored app's demo model on this sample
			const oJSONModel = this.initSampleDataModel();
		
		},
        onAfterRendering:function(){
          

        },

		initSampleDataModel: function() {
			let buyOrderTypes=[{
				"id":"MARKET",
				"name":"MARKET"
			},{
				"id":"LIMIT",
				"name":"LIMIT"
			}];

			sap.ui.getCore().getModel("watchlist").setProperty("/buyOrderTypes",buyOrderTypes);

			let sellOrderTypes=[{
				"id":"MARKET",
				"name":"MARKET"
			},{
				"id":"LIMIT",
				"name":"LIMIT"
			}];

			sap.ui.getCore().getModel("watchlist").setProperty("/sellOrderTypes",sellOrderTypes);
			sap.ui.getCore().getModel("watchlist").setProperty("/add",{});
			sap.ui.getCore().getModel("watchlist").setProperty("/add/targetTypePoints",true);
			sap.ui.getCore().getModel("watchlist").setProperty("/add/stopLossTypePoints",true);
			sap.ui.getCore().getModel("watchlist").setProperty("/add/lossvalue","0.00");
			sap.ui.getCore().getModel("watchlist").setProperty("/add/profitvalue","0.00");
			sap.ui.getCore().getModel("watchlist").setProperty("/add/lotsize","0.01");


			
			
			this.getAllStrategies();
			this.loadSymbols();
		},

		initSellOrderModel: function(){
			sap.ui.getCore().getModel("watchlist").setProperty("/sell",{});
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/targetTypePoints",true);
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/stopLossTypePoints",true);
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/sell_order_type","MARKET");
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/openprice",null);
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/profitvalue",null);
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/lossvalue",null);

			sap.ui.getCore().getModel("watchlist").setProperty("/sell/lotsize","0.01");

		},
		initBuyOrderModel: function(){
			sap.ui.getCore().getModel("watchlist").setProperty("/buy",{});
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/targetTypePoints",true);
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/stopLossTypePoints",true);
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/buy_order_type","MARKET");
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/openprice",null);
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/profitvalue",null);
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/lossvalue",null);

			sap.ui.getCore().getModel("watchlist").setProperty("/buy/lotsize","0.01");
		},
		onBuySymbol:async function(oEvent){
			let spath =oEvent.getSource().getBindingContext("watchlist").getPath();
			let strategy=sap.ui.getCore().getModel("watchlist").getProperty(spath);
			this.initBuyOrderModel();
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/symbol",strategy.symbol);
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/stategyname",strategy.name);
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/stategyid",strategy._id);
			
			let currentMarketPrice=await this.getCurrentSymbolMarketValue(strategy.symbol);
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/askprice",currentMarketPrice);

			var oView = this.getView();
			if (!this.oBuyOrder) {
				this.oBuyOrder = this.loadFragment({
					name: "com.forex.app.fragment.BuyOrder",
					controller: this
				});
			}
			this.oBuyOrder.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oBuyOrderDialog = oDialog;
				this.oBuyOrderDialog.open();


			}.bind(this));

			

		},
		onSellSymbol:async function(oEvent){
			let spath =oEvent.getSource().getBindingContext("watchlist").getPath();
			let strategy=sap.ui.getCore().getModel("watchlist").getProperty(spath);
			this.initSellOrderModel();
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/symbol",strategy.symbol);
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/stategyname",strategy.name);
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/stategyid",strategy._id);
			
			let currentMarketPrice=await this.getCurrentSymbolMarketValue(strategy.symbol);
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/askprice",currentMarketPrice);

			var oView = this.getView();
			if (!this.oSellOrder) {
				this.oSellOrder = this.loadFragment({
					name: "com.forex.app.fragment.SellOrder",
					controller: this
				});
			}
			this.oSellOrder.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oSellOrderDialog = oDialog;
				this.oSellOrderDialog.open();


			}.bind(this));

			

		},

		closeBuyOrderDialog:function(){
			this.oBuyOrderDialog.close();
			this.getView().removeDependent(this.oBuyOrderDialog);

			this.oBuyOrderDialog.destroy();
			this.oBuyOrder=null;
		},
		closeSellOrderDialog:function(){
			this.oSellOrderDialog.close();
			this.getView().removeDependent(this.oSellOrderDialog);

			this.oSellOrderDialog.destroy();
			this.oSellOrder=null;
		},
		

		handleBuyorderTypes :function(oEvent){

			let ValueState = coreLibrary.ValueState
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Please enter a buy order type");
			} else {
			 sap.ui.getCore().getModel("watchlist").setProperty("/buy/buy_order_type",sSelectedKey);
				oValidatedComboBox.setValueState(ValueState.None);
			}

		},
		handleSellOrderTypes:function(oEvent){

			
			let ValueState = coreLibrary.ValueState
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Please enter a sell order type");
			} else {
			 sap.ui.getCore().getModel("watchlist").setProperty("/sell/sell_order_type",sSelectedKey);
				oValidatedComboBox.setValueState(ValueState.None);
			}

		},
		onAddSymbol:async function(){
			let data =sap.ui.getCore().getModel("watchlist").getProperty("/add");


			let url =`${window.terminalurl}/users/current/accounts/${accountid}/trade`
			let postdata={};
			postdata.actionType=data.buy_order_type;
			postdata.symbol=data.symbol;
			postdata.volume=parseFloat(data.lotsize);

			let strategyData=await this.getStrategy(data.strategyid);
			let updateSymbolsData={};
			updateSymbolsData.name=strategyData.name;
			updateSymbolsData.accountId=strategyData.accountId;
			updateSymbolsData.description=strategyData.description;
			

			if(!strategyData.symbolsTraded ){
				updateSymbolsData.symbolsTraded=[data.symbol]
			}else{
				let index =strategyData.symbolsTraded.indexOf(data.symbol);
				if(index==-1){
					updateSymbolsData.symbolsTraded.push(data.symbol);
				}
			}

			await axios.put(`${window.copyfactoryurl}/users/current/configuration/strategies/${data.strategyid}`,updateSymbolsData);

			
			if(data.targetTypePoints){
				if(data.buy_order_type=="ORDER_TYPE_BUY"){
					let symbolMarketValue =await this.getCurrentSymbolMarketValue(data.symbol);
				//	postdata.symbol="BTC";
			
					postdata.takeProfit= parseFloat(symbolMarketValue)+parseFloat(data.profitvalue);
					postdata.stopLoss= parseFloat(symbolMarketValue)-parseFloat(data.lossvalue);

				}


			}

		        await axios.post(url,postdata);
		},
		/*handleSquareOFFALL: async function(){
			await this.getOpenOrders();
			let data=sap.ui.getCore().getModel("watchlist").getProperty("/openorders") ;
			let url =`${window.terminalurl}/users/current/accounts/${accountid}/trade`;
			for(let i=0;i<data.length;i++){
				let payload={
					"actionType":"ORDER_CANCEL",
					"orderId":data[i].id
				}
				 axios.post(url,payload);
			}

		},*/
		handleCancelOrder:async function(oEvent){

			let spath =oEvent.getSource().getBindingContext("watchlist").getPath();
			let order=sap.ui.getCore().getModel("watchlist").getProperty(spath);

			let payload={
				"actionType":"POSITIONS_CLOSE_SYMBOL",
				"symbol":order.symbol
			}
		
			 await this.handleTradingErrors(null,payload,null,null,this);	

		},

		getOpenOrders: async function(){
			let url =`${window.terminalurl}/users/current/accounts/${accountid}/orders`;
			let response =await axios.get(url);
			let data=response.data;
			for(let i=0;i<data.length;i++){

			}
sap.ui.getCore().getModel("watchlist").setProperty("/openorders",data);
		

		},

		getStrategy:async function(strategyid){
		let strategiesurl=`${window.copyfactoryurl}/users/current/configuration/strategies/${strategyid}`;
		let response =await axios.get(strategiesurl);
		return response.data;
		},

		getCurrentSymbolMarketValue:async function(symbolid){

			let url =`${window.terminalurl}/users/current/accounts/${accountid}/symbols/${symbolid}/current-price`
			

			const response = await axios.get(url);
			return response.data.ask


		},
		
		handleStrategyChange :function(oEvent){

			let ValueState = coreLibrary.ValueState
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Please select Strategy ");
			} else {
			 sap.ui.getCore().getModel("watchlist").setProperty("/add/strategyid",sSelectedKey);
				oValidatedComboBox.setValueState(ValueState.None);
			}

		},
		placeBuyOrder:async function(){
		
			let buyorderpayload={}
			buyorderpayload.actionType="ORDER_TYPE_BUY";
			buyorderpayload.comment=sap.ui.getCore().getModel("watchlist").getProperty("/buy/stategyid");
			buyorderpayload.symbol=sap.ui.getCore().getModel("watchlist").getProperty("/buy/symbol");
			buyorderpayload.volume=sap.ui.getCore().getModel("watchlist").getProperty("/buy/lotsize");
			buyorderpayload.volume=parseFloat(buyorderpayload.volume);

			let stopLossTypePoints=sap.ui.getCore().getModel("watchlist").getProperty("/buy/stopLossTypePoints")
			let targetTypePoints=sap.ui.getCore().getModel("watchlist").getProperty("/buy/targetTypePoints")
            let profitvalue =sap.ui.getCore().getModel("watchlist").getProperty("/buy/profitvalue");
			let lossvalue =sap.ui.getCore().getModel("watchlist").getProperty("/buy/lossvalue");
			let buyordertype=sap.ui.getCore().getModel("watchlist").getProperty("/buy/buy_order_type");
           let symbol =sap.ui.getCore().getModel("watchlist").getProperty("/buy/symbol");
			let symbolValue=null;
			if(buyordertype=="MARKET"){
				symbolValue=await this.getCurrentSymbolMarketValue(symbol)
			
				symbolValue=parseFloat(symbolValue);
				
			}else{
				symbolValue=sap.ui.getCore().getModel("watchlist").getProperty("/buy/openprice")
			
				symbolValue=parseFloat(symbolValue);
				buyorderpayload.openPrice=symbolValue;
				buyorderpayload.actionType="ORDER_TYPE_BUY_LIMIT";
				
			}
			



				if(targetTypePoints){

					if(profitvalue){
						profitvalue =parseFloat(parseFloat(profitvalue).toFixed(2));
						buyorderpayload.takeProfit=profitvalue;
	
					}
	
				}else{
					if(profitvalue){
						profitvalue =parseFloat(parseFloat(profitvalue).toFixed(2));
						profitvalue =await this.calculateProfitPercentage(profitvalue,symbolValue);
						buyorderpayload.takeProfit=profitvalue;
					}
	
				}
	
				if(stopLossTypePoints){
					if(lossvalue){
						lossvalue =parseFloat(parseFloat(lossvalue).toFixed(2));
						buyorderpayload.stopLoss=lossvalue;
					}
	
	
	
				}else{

					if(lossvalue){
						lossvalue =parseFloat(parseFloat(lossvalue).toFixed(2));
						lossvalue =await this.calculateLossPercentage(lossvalue,symbolValue);
						buyorderpayload.stopLoss=lossvalue;
					}

	
				}

				await this.handleTradingErrors(null,buyorderpayload,this.closeBuyOrderDialog,null,this);				
				


			
		},
		placeSellOrder:async function(){
			let buyorderpayload={}
			buyorderpayload.actionType="ORDER_TYPE_SELL";
			buyorderpayload.comment=sap.ui.getCore().getModel("watchlist").getProperty("/sell/stategyid");
			buyorderpayload.symbol=sap.ui.getCore().getModel("watchlist").getProperty("/sell/symbol");
			buyorderpayload.volume=sap.ui.getCore().getModel("watchlist").getProperty("/sell/lotsize");
			buyorderpayload.volume=parseFloat(buyorderpayload.volume);

			let stopLossTypePoints=sap.ui.getCore().getModel("watchlist").getProperty("/sell/stopLossTypePoints")
			let targetTypePoints=sap.ui.getCore().getModel("watchlist").getProperty("/sell/targetTypePoints")
            let profitvalue =sap.ui.getCore().getModel("watchlist").getProperty("/sell/profitvalue");
			let lossvalue =sap.ui.getCore().getModel("watchlist").getProperty("/sell/lossvalue");
			let buyordertype=sap.ui.getCore().getModel("watchlist").getProperty("/sell/sell_order_type");
           let symbol =sap.ui.getCore().getModel("watchlist").getProperty("/sell/symbol");
			let symbolValue=null;
			if(buyordertype=="MARKET"){
				symbolValue=await this.getCurrentSymbolMarketValue(symbol)
			
				symbolValue=parseFloat(symbolValue);
				
			}else{
				symbolValue=sap.ui.getCore().getModel("watchlist").getProperty("/sell/openprice")
			
				symbolValue=parseFloat(symbolValue);
				buyorderpayload.openPrice=symbolValue;
				buyorderpayload.actionType="ORDER_TYPE_SELL_LIMIT";
				
			}
			



				if(targetTypePoints){

					if(profitvalue){
						profitvalue =parseFloat(parseFloat(profitvalue).toFixed(2));
						buyorderpayload.takeProfit=profitvalue;
	
					}
	
				}else{
					if(profitvalue){
						profitvalue =parseFloat(parseFloat(profitvalue).toFixed(2));
						profitvalue =await this.calculateLossPercentage(profitvalue,symbolValue);
						buyorderpayload.takeProfit=profitvalue;
					}
	
				}
	
				if(stopLossTypePoints){
					if(lossvalue){
						lossvalue =parseFloat(parseFloat(lossvalue).toFixed(2));
						buyorderpayload.stopLoss=lossvalue;
					}
	
	
	
				}else{

					if(lossvalue){
						lossvalue =parseFloat(parseFloat(lossvalue).toFixed(2));
						lossvalue =await this.calculateProfitPercentage(lossvalue,symbolValue);
						buyorderpayload.stopLoss=lossvalue;
					}

	
				}



				await this.handleTradingErrors(null,buyorderpayload,this.closeSellOrderDialog,null,this);				
				
	           
		},
		calculateProfitPercentage:async function(percentage,amount) {
			percentage=parseFloat(percentage)/100;
			amount=parseFloat(amount);
			amount= amount + (amount * percentage);
			amount =parseFloat(parseFloat(amount.toFixed(2)));
			return amount;

		},
		calculateLossPercentage:async function(percentage,amount) {
			percentage=parseFloat(percentage)/100;
			
			amount=parseFloat(amount);
			amount= amount - (amount * percentage);
			amount =parseFloat(parseFloat(amount.toFixed(2)));
			return amount;

		},
		setTargetTypePoints:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/targetTypePoints",value);
			
		},

		setSellTargetTypePoints:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/targetTypePoints",value);
			
		},



		setTargetTypePecentage:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/targetTypePoints",!value);
		},

		setSellTargetTypePecentage:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/targetTypePoints",!value);
		},


		setStopLostTypePoints:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/stopLossTypePoints",value);
			
		},

		setSellStopLostTypePoints:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/stopLossTypePoints",value);
			
		},
		setStopLostTypePercentage:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/buy/stopLossTypePoints",!value);
		},
		setSellStopLostTypePercentage:function(oEvent){
			let value = oEvent.getParameter("selected");
			sap.ui.getCore().getModel("watchlist").setProperty("/sell/stopLossTypePoints",!value);
		},
		onEntryOrderChange:function(buy_order_type){
			if(buy_order_type=="MARKET"){
				sap.ui.getCore().getModel("watchlist").setProperty("/buy/openprice",null);
				return false;
			}else{
				return true;
			}

		},
		onEntrySellOrderChange:function(buy_order_type){
			if(buy_order_type=="MARKET"){
				sap.ui.getCore().getModel("watchlist").setProperty("/sell/openprice",null);
				return false;
			}else{
				return true;
			}

		},

		getAllStrategies:async function(){

			let strategiesurl=`${window.copyfactoryurl}/users/current/configuration/strategies`
			let strategies = await this.fetchAllData([strategiesurl]);
		
			//l//et strategiesArray=[]
			
			sap.ui.getCore().getModel("watchlist").setProperty("/strategies",strategies[0]);
			this.prepareDataForView();

		},

		prepareDataForView:async function(){
			let data =sap.ui.getCore().getModel('watchlist').getProperty("/strategies");
			let preparedData=[];
			for(let i=0;i<data.length;i++){
				let stategy=data[i];

				if(stategy.symbolFilter && stategy.symbolFilter.included){
					for(let j=0;j<stategy.symbolFilter.included.length;j++){
						let payload =JSON.parse(JSON.stringify(stategy));
						
						payload.symbol=stategy.symbolFilter.included[j];
						preparedData.push(payload);
					}

				}else{
					preparedData.push(stategy);
				}

			}
			sap.ui.getCore().getModel("watchlist").setProperty("/strategieslist",preparedData);

		},

		onSelectionModeChange: function(oEvent) {
			if (oEvent.getParameter("selectedItem").getKey() === "All") {
				MessageToast.show("selectionMode:All is deprecated. Please select another one.");
				return;
			}
			const oTable = this.byId("table1");
			oTable.setSelectionMode(oEvent.getParameter("selectedItem").getKey());
		},

		onBehaviourModeChange: function(oEvent) {
			const oTable = this.byId("table1");
			oTable.setSelectionBehavior(oEvent.getParameter("selectedItem").getKey());
		},

		onSwitchChange: function(oEvent) {
			const oTable = this.byId("table1");
			oTable.setEnableSelectAll(oEvent.getParameter("state"));
		},

		

		handleSymbolValueHelp : function (oEvent) {
			var oView = this.getView();
			this.inputId = oEvent.getSource().getId();

			// create value help dialog
			if (!this._pSymbolValueHelpDialog) {
				this._pSymbolValueHelpDialog = this.loadFragment({
				
					name:  "com.forex.app.fragment.Dialog",
					controller: this
				}).then(function(oValueHelpDialog){
					oView.addDependent(oValueHelpDialog);
					return oValueHelpDialog;
				});
			}

			this._pSymbolValueHelpDialog.then(function(oValueHelpDialog){
				debugger;
				// open value help dialog
				oValueHelpDialog.open();
			}).catch(function(err){
				debugger;
			});
		},

		loadSymbols:async function(){
			let symbolsurl=`${window.terminalurl}/users/current/accounts/${window.accountid}/symbols`
			let symbols = await this.fetchAllData([symbolsurl]);
			debugger;
			let symbolArray=[]
			for(let i=0;i<symbols[0].length;i++){
				symbolArray.push({
					"name":symbols[0][i]
				})

			}
			sap.ui.getCore().getModel("watchlist").setProperty("/symbols",symbolArray);
			

		},
		_handleSymbolValueHelpSearch : function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"name",
				FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleSymbolValueHelpClose : function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput =sap.ui.getCore().byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		

		openManagedStategies: async function(evt) {
            var oView = this.getView();
		//	await this.loadSymbols();
			if (!this.oManageStrategies) {
				this.oManageStrategies = this.loadFragment({
					name: "com.forex.app.fragment.WatchList",
                    controller: this
				});
			}
			this.oManageStrategies.then(function (oDialog) {
                oView.addDependent(oDialog); 
				this.oManageStrategiesDialog = oDialog;
				this.oManageStrategiesDialog.open();
               
				
			}.bind(this));
		},
		closeManageStategies:function(){
			this.oManageStrategiesDialog.close();

		},

		getContextByIndex: function(evt) {
			const oTable = this.byId("table1");
			const iIndex = oTable.getSelectedIndex();
			let sMsg;
			if (iIndex < 0) {
				sMsg = "no item selected";
			} else {
				sMsg = oTable.getContextByIndex(iIndex);
			}
			MessageToast.show(sMsg);
		},

		clearSelection: function(evt) {
			this.byId("table1").clearSelection();
		},

		formatAvailableToObjectState: function(bAvailable) {
			return bAvailable ? "Success" : "Error";
		},

		formatAvailableToIcon: function(bAvailable) {
			return bAvailable ? "sap-icon://accept" : "sap-icon://decline";
		},

		handleDetailsPress: function(oEvent) {
			MessageToast.show("Details for product with id " + this.getView().getModel().getProperty("ProductId", oEvent.getSource().getBindingContext()));
		}

	});

});