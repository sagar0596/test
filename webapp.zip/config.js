export var firebaseConfig = {
    apiKey: "AIzaSyBVCoKArtgF2HL5a3OPZ2o0o8GkiviSMaA",
    authDomain: "localhost",
    projectId: "betroddfxlocal",
    storageBucket: "betroddfxlocal.firebasestorage.app",
    messagingSenderId: "16226040607",
    appId: "1:16226040607:web:9eeaa833c4860132d34e2a"
};
