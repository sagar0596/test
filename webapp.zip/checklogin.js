import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js';
import { createUserWithEmailAndPassword, getAuth, onAuthStateChanged, sendEmailVerification, sendPasswordResetEmail, signInWithEmailAndPassword, signOut, } from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js';
import { firebaseConfig } from './config.js';

import {getFirestore ,getDocs,collection ,getDoc,doc} from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js';


const app =initializeApp(firebaseConfig);
window.auth = getAuth();
// Listening for auth state changes.
onAuthStateChanged(auth, async function (user) {
   
     if (user) {
        debugger;
      window.username=user.email;
      window.uid=user.uid
      const db = getFirestore(app);

      const userId = auth.currentUser.uid;
      const userDoc = await getDoc(doc(db, "users", userId));

     let userdata= userDoc.data();
     window.accountid=userdata.aid;
     window.metatoken=userdata.tid;
     // Start the OpenUI5 application after data is fetched
     sap.ui.require([
        "sap/ui/core/Component",
        "sap/ui/core/ComponentContainer"
      ], function (Component, ComponentContainer) {
        // Create the Component asynchronously
        Component.create({
          name: "com.forex.app",
          id: "forexapp"
        }).then(function (oComponent) {
          // Place the Component in the DOM
          new ComponentContainer({
            component: oComponent
          }).placeAt("container");
        });
      });

     } else {
        debugger;
     }
    
});
window.signOut=signOut;
