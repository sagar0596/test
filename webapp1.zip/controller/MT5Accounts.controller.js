sap.ui.define([
	'./BaseController',
	"sap/base/Log",
	"sap/ui/table/library",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat",
	"sap/ui/thirdparty/jquery",
	"sap/ui/core/date/UI5Date"
], function (BaseController, Log, library, Controller, MessageToast, JSONModel, DateFormat, jQuery, UI5Date) {
	"use strict";

	const SelectionBehavior = library.SelectionBehavior;
	const SelectionMode = library.SelectionMode;
	return BaseController.extend("com.forex.app.controller.UsagarStatistics", {
		onInit: function () {
			this.initSampleDataModel();


		},
		onAfterRendering: function () {


		},
		// Function to fetch data with error handling
 /*fetchDataWithErrorHandling : async function(url)  {
   
        const response = await axios.get(url);
        return response.data; // Return the data from the response
   
},

// Main function to make parallel API calls
 fetchAllData : async function(apiUrls) {
    
        // Create an array of promises with error handling
        const promises = apiUrls.map(url => this.fetchDataWithErrorHandling(url));

        // Use Promise.all to make parallel calls
        const results = await Promise.all(promises);
		return results;

       
   
},*/


		initSampleDataModel: async function () {
			try{
			 	let accounts=await axios.get("/users/current/accounts?limit=10&offset=0");
				let accounturls=[];
				let accounttermialurl=[];
				let strategyurl=[];
				for(let i=0;i<accounts.data.length;i++){
					let account=accounts.data[i];
					let accountid=account._id;
					accounturls.push(`/users/current/accounts/${accountid}`);
					accounttermialurl.push(`${window.terminalurl}/users/current/accounts/${accountid}/account-information`)
					strategyurl.push(`${window.copyfactoryurl}/users/current/configuration/subscribers/${accountid}`)
					
				}
				let accountresultsP = this.fetchAllData(accounturls);
				let accounttermialurlresultP= this.fetchAllData(accounttermialurl);
				let strategyurlresultP= this.fetchAllData(strategyurl);
				let accountresult= await accountresultsP;
				let accounttermialurlresult=await accounttermialurlresultP;
				let stategyurlresult=await strategyurlresultP;
				let results=[];
				for(let i=0;i<accounts.data.length;i++){
					let data=accounttermialurlresult[i];
					data.name=accountresult[i].name;
					data.account_id=accounts.data[i]._id;
					data.server=accounts.data[i].server;
					//data.tags=accountresult[i].tags;
					data.tags=["asdsad","asdsdsa"];
					data.strategies=stategyurlresult[i].subscriptions;
					results.push(data);

				}
				sap.ui.getCore().getModel("mts_accounts").setProperty("/accounts", results);

			}catch(err){
				console.error(err);

			}




		},
		handleEditAccount :function(oEvent){
			let spath =oEvent.getSource().getBindingContext("mts_accounts").getPath();
			let account=sap.ui.getCore().getModel("mts_accounts").getProperty(spath);
			
			let accountdata=Object.assign({}, account);
			sap.ui.getCore().getModel("mts_accounts").setProperty("/account",accountdata);

			var oView = this.getView();
			if (!this.oEditAccount) {
				this.oEditAccount = this.loadFragment({
					name: "com.forex.app.fragment.EditAccount",
					controller: this
				});
			}
			this.oEditAccount.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oEditAccountDialog = oDialog;
				this.oEditAccountDialog.open();


			}.bind(this));

		},

		handleAddAccount: function(){

			
			sap.ui.getCore().getModel("mts_accounts").setProperty("/addaccount",{});

			var oView = this.getView();
			if (!this.oAddAccount) {
				this.oAddAccount = this.loadFragment({
					name: "com.forex.app.fragment.AddAccount",
					controller: this
				});
			}
			this.oAddAccount.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oAddAccountDialog = oDialog;
				this.oAddAccountDialog.open();


			}.bind(this));

		},
		onSaveAccountChanges:async function(){
			let accountid=sap.ui.getCore().getModel("mts_accounts").getProperty("/account/account_id")
			let url=`/users/current/accounts/${accountid}`
			let name =sap.ui.getCore().getModel("mts_accounts").getProperty("/account/name");
			let server =sap.ui.getCore().getModel("mts_accounts").getProperty("/account/server")
			const response = await axios.put(url,{
				name:name,
				server:"Exness-MT5Trial14",
				password:"Tayyaba@1687"
			});
			debugger;

		},

		onCancelAccountChanges: function(){
			this.oEditAccountDialog.close();
		},

		onAddAccount:async function(){
		
			let data =sap.ui.getCore().getModel("mts_accounts").getProperty("/addaccount");
			data.magic=0;
			data.platform="mt5";
			data.copyFactoryRoles=["SUBSCRIBER"];
			
			
			data.region="london";

			const headers = {
				'transaction-id':this.generateTranscationid(),
				
			  }
			const response = await axios.post("/users/current/accounts",data,{
				headers: headers
			  });
			debugger;

		},

		 generateTranscationid : function(){
			const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
			let result = '';
			const length = 32;
			for (let i = 0; i < length; i++) {
				const randomIndex = Math.floor(Math.random() * characters.length);
				result += characters[randomIndex];
			}
			return result;
		},

		onCancelAddAccount: function(){
			this.oAddAccountDialog.close();
		},
		onCloseManagedStategies :function(){
			this.oManageStrategiesDialog.close();
		},

		initSampleDataModelod: async function () {

			let tradingaccountsdata = [];

			const accounts = await api.metatraderAccountApi.getAccountsWithInfiniteScrollPagination({
				limit: 10,
				offset: 0,

				state: ['DEPLOYED']
			});

			for (let i = 0; i < accounts.length; i++) {
				const account = accounts[i]
				const accountId = account.id;
				try {
					let account = await api.metatraderAccountApi.getAccount(accountId);

					// wait until account is deployed and connected to broker
					console.log('Deploying account');
					if (account.state !== 'DEPLOYED') {
						await account.deploy();
					} else {
						console.log('Account already deployed');
					}
					console.log('Waiting for API server to connect to broker (may take couple of minutes)');
					if (account.connectionStatus !== 'CONNECTED') {
						await account.waitConnected();
					}
					// connect to MetaApi API
					let connection = account.getRPCConnection();
					await connection.connect();
					log('Waiting for SDK to synchronize to terminal state (may take some time depending on your history size)');
					await connection.waitSynchronized();
					await connection.getAccountInformation();
					tradingaccountsdata.push(account._data)
					/*let metrics = await metaStats.getMetrics(accountId);
					console.log(metrics);//-> {trades: ..., balance: ..., ...}
					
					let trades = await metaStats.getAccountTrades(accountId, '0000-01-01 00:00:00.000', '9999-01-01 00:00:00.000');
					console.log(trades.slice(-5));//-> {_id: ..., gain: ..., ...}
					
					let openTrades = await metaStats.getAccountOpenTrades(accountId);
					console.log(openTrades);//-> {_id: ..., gain: ..., ...}*/

				} catch (err) {
					console.error(err);
				}
			}

			//		  this.getOwnerComponent().getModel("mts_accounts").setProperty("/accounts", tradingaccountsdata);

			sap.ui.getCore().getModel("mts_accounts").setProperty("/accounts", tradingaccountsdata);





		},

		onSelectionModeChange: function (oEvent) {
			if (oEvent.getParameter("selectedItem").getKey() === "All") {
				MessageToast.show("selectionMode:All is deprecated. Please select another one.");
				return;
			}
			const oTable = this.byId("table1");
			oTable.setSelectionMode(oEvent.getParameter("selectedItem").getKey());
		},

		onBehaviourModeChange: function (oEvent) {
			const oTable = this.byId("table1");
			oTable.setSelectionBehavior(oEvent.getParameter("selectedItem").getKey());
		},

		onSwitchChange: function (oEvent) {
			const oTable = this.byId("table1");
			oTable.setEnableSelectAll(oEvent.getParameter("state"));
		},

		openManagedStategies: function (evt) {
			var oView = this.getView();
			sap.ui.getCore().getModel("mts_accounts").setProperty("/newstrategy",{});
			this.onGetStrategies();
			if (!this.oMPDialog) {
				this.oMPDialog = this.loadFragment({
					name: "com.forex.app.fragment.ManagedStrategies",
					controller: this
				});
			}
			this.oMPDialog.then(function (oDialog) {
				oView.addDependent(oDialog);
				this.oManageStrategiesDialog = oDialog;
				this.oManageStrategiesDialog.open();


			}.bind(this));
		},

		onAddStrategy: async function (evt) {
			debugger;
            let data=sap.ui.getCore().getModel("mts_accounts").getProperty("/newstrategy");
			data.name=data.name.trim();
			if(data.name.length==0){
				return;
			}
			data.accountId=window.accountid;
			let url=`${window.copyfactoryurl}/users/current/configuration/unused-strategy-id`;
			const response = await axios.get(url);
			let strategyid=response.data.id;
			let updatestrategyurl=`${window.copyfactoryurl}/users/current/configuration/strategies/${strategyid}`
			

			await axios.put(updatestrategyurl,data);

			this.oManageStrategiesDialog.close();
			sap.ui.getCore().getModel("mts_accounts").setProperty("/newstrategy",{})
			
		},

		onGetStrategies: async function (evt) {
			sap.ui.getCore().getModel("mts_accounts").getProperty("/all_stategies");
			
			let url=`${window.copyfactoryurl}/users/current/configuration/strategies`;
			const response = await axios.get(url);

			sap.ui.getCore().getModel("mts_accounts").setProperty("/all_stategies",response.data);
			
		},

		getContextByIndex: function (evt) {
			const oTable = this.byId("table1");
			const iIndex = oTable.getSelectedIndex();
			let sMsg;
			if (iIndex < 0) {
				sMsg = "no item selected";
			} else {
				sMsg = oTable.getContextByIndex(iIndex);
			}
			MessageToast.show(sMsg);
		},

		clearSelection: function (evt) {
			this.byId("table1").clearSelection();
		},

		formatAvailableToObjectState: function (bAvailable) {
			return bAvailable ? "Success" : "Error";
		},

		formatAvailableToIcon: function (bAvailable) {
			return bAvailable ? "sap-icon://accept" : "sap-icon://decline";
		},

		handleDetailsPress: function (oEvent) {
			MessageToast.show("Details for product with id " + this.getView().getModel().getProperty("ProductId", oEvent.getSource().getBindingContext()));
		}

	});

});