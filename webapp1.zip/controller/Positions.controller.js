

sap.ui.define([
    './BaseController',
   
    "sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
    "use strict";

    return BaseController.extend("com.forex.app.controller.Positions", {
        onInit: function () {
            // Load JSON data from file and set it as the model
            const oJSONModel = this.initSampleDataModel();
			

            // Log the model data
           // console.log("Model Data:", oModel.getData());
        },

        getGroup: function (oContext) {
            return oContext.getProperty('name');
        },
   getGroupHeader: function (oGroup) {
          
            return new sap.m.GroupHeaderListItem({
                title: oGroup.key
            })
        },
        initSampleDataModel: async function() {

            let accounts=await axios.get("/users/current/accounts?limit=10&offset=0");
				let accounturls=[];
				let accounttermialurl=[];
                let promise=[];
				for(let i=0;i<accounts.data.length;i++){
					let account=accounts.data[i];
					let accountid=account._id;
					
					promise.push(this.fetchDataWithErrorHandling(`${window.terminalurl}/users/current/accounts/${accountid}/positions`));
				}
			let result =await Promise.all(promise);
            let finalresult=[];
            for(let i=0;i<result.length;i++){
                let account=accounts.data[i]
                for(let j=0;j<result[i].length;j++){
                    result[i][j]["name"]=account["name"];
                  let date   = new Date( result[i][j]["time"]); 
                     result[i][j]["time"] = 
                ("00" + (date.getMonth() + 1)).slice(-2) 
                + "/" + ("00" + date.getDate()).slice(-2) 
                + "/" + date.getFullYear() + " " 
                + ("00" + date.getHours()).slice(-2) + ":" 
                + ("00" + date.getMinutes()).slice(-2) 
                + ":" + ("00" + date.getSeconds()).slice(-2); 
                    finalresult.push( result[i][j]);

                }
            }
            debugger;


            sap.ui.getCore().getModel("positions").setProperty("/positions",finalresult);

		},
    });
});